#include "MAVLinkSystem.h"

#include "MAVLinkMessage.h"
#include "QGCLoggingCategory.h"
#include "QmlObjectListModel.h"

#include <algorithm>

QGC_LOGGING_CATEGORY(MAVLinkSystemLog, "AnalyzeView.MAVLinkSystem")

QGCMAVLinkSystem::QGCMAVLinkSystem(quint8 id, QObject *parent)
    : QObject(parent)
    , _systemID(id)
    , _messages(new QmlObjectListModel(this))
{
    qCDebug(MAVLinkSystemLog) << "New Vehicle:" << id;
}

QGCMAVLinkSystem::~QGCMAVLinkSystem()
{
    _messages->clearAndDeleteContents();
}

QGCMAVLinkMessage *QGCMAVLinkSystem::findMessage(uint32_t id, uint8_t compId, const QString &instanceValue)
{
    for (int i = 0; i < _messages->count(); i++) {
        QGCMAVLinkMessage *const msg = qobject_cast<QGCMAVLinkMessage*>(_messages->get(i));
        if(msg) {
            if((msg->id() == id) && (msg->compId() == compId) && (msg->instanceValue() == instanceValue)) {
                return msg;
            }
        }
    }

    return nullptr;
}

int QGCMAVLinkSystem::findMessage(const QGCMAVLinkMessage *message)
{
    for (int i = 0; i < _messages->count(); i++) {
        const QGCMAVLinkMessage *const msg = qobject_cast<const QGCMAVLinkMessage*>(_messages->get(i));
        if (msg && (msg == message)) {
            return i;
        }
    }

    return -1;
}

void QGCMAVLinkSystem::_resetSelection()
{
    for (int i = 0; i < _messages->count(); i++) {
        QGCMAVLinkMessage *const msg = qobject_cast<QGCMAVLinkMessage*>(_messages->get(i));
        if (msg && msg->selected()) {
            msg->setSelected(false);
        }
    }
}

void QGCMAVLinkSystem::setSelected(int sel)
{
    if (sel < 0 || sel >= _messages->count()) {
        return;
    }

    _selected = sel;
    emit selectedChanged();
    _resetSelection();
    QGCMAVLinkMessage *const msg = qobject_cast<QGCMAVLinkMessage*>(_messages->get(sel));
    if (msg && !msg->selected()) {
        msg->setSelected(true);
    }
}

QGCMAVLinkMessage *QGCMAVLinkSystem::selectedMsg()
{
    QGCMAVLinkMessage *selectedMsg = nullptr;
    if (_messages->count()) {
        selectedMsg = qobject_cast<QGCMAVLinkMessage*>(_messages->get(_selected));
    }

    return selectedMsg;
}

void QGCMAVLinkSystem::append(QGCMAVLinkMessage *message)
{
    QGCMAVLinkMessage *selectedMsg = nullptr;
    if (_messages->count()) {
        selectedMsg = qobject_cast<QGCMAVLinkMessage*>(_messages->get(_selected));
    } else {
        message->setSelected(true);
    }
    const auto cmp = [](const QObject *a, const QObject *b) {
        const auto *ma = qobject_cast<const QGCMAVLinkMessage*>(a);
        const auto *mb = qobject_cast<const QGCMAVLinkMessage*>(b);
        if (!ma || !mb) return false;
        return ma->name() < mb->name();
    };
    QList<QObject*> *const list = _messages->objectList();
    const int insertPos = static_cast<int>(std::lower_bound(list->cbegin(), list->cend(), static_cast<const QObject*>(message), cmp) - list->cbegin());
    _messages->insert(insertPos, message);
    _checkCompID(message);

    if (selectedMsg) {
        const int idx = findMessage(selectedMsg);
        if (idx >= 0) {
            _selected = idx;
            emit selectedChanged();
        }
    }
}

void QGCMAVLinkSystem::_checkCompID(const QGCMAVLinkMessage *message)
{
    if (_compIDsStr.isEmpty()) {
        _compIDsStr << tr("Comp All");
    }

    if (!_compIDs.contains(static_cast<int>(message->compId()))) {
        const int compId = static_cast<int>(message->compId());
        _compIDs.append(compId);
        _compIDsStr << tr("Comp %1").arg(compId);
        emit compIDsChanged();
    }
}
