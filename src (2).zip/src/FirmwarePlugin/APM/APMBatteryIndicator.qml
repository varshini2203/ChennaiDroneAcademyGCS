import QtQuick
import QtQuick.Layouts

import QGroundControl
import QGroundControl.Controls
import QGroundControl.FactControls

ColumnLayout {
    FactPanelController { id: controller }

    property Fact batt1Monitor: controller.getParameterFact(-1, "BATT_MONITOR")
    property string disabledString: qsTr("- disabled")

    SettingsGroupLayout {
        Layout.fillWidth:   true
        heading:            qsTr("Low Voltage Failsafe")
        visible:            batt1Monitor.rawValue !== 0

        LabelledFactComboBox {
            label:              qsTr("Vehicle Action")
            fact:               controller.getParameterFact(-1, "BATT_FS_LOW_ACT")
            indexModel:         false
        }

        FactSlider {
            Layout.fillWidth:   true
            label:              qsTr("Voltage Trigger") + (value == 0 ? disabledString : "")
            fact:               controller.getParameterFact(-1, "BATT_LOW_VOLT")
            from:               0
            to:                 100
            majorTickStepSize:  5
        }

        FactSlider {
            Layout.fillWidth:   true
            label:              qsTr("mAh Trigger") + (value == 0 ? disabledString : "")
            fact:               controller.getParameterFact(-1, "BATT_LOW_MAH")
            from:               0
            to:                 30000
            majorTickStepSize:  1000
        }
    }

    SettingsGroupLayout {
        Layout.fillWidth:   true
        heading:            qsTr("Critical Voltage Failsafe")
        visible:            batt1Monitor.rawValue !== 0

        LabelledFactComboBox {
            label:              qsTr("Vehicle Action")
            fact:               controller.getParameterFact(-1, "BATT_FS_CRT_ACT")
            indexModel:         false
        }

        FactSlider {
            Layout.fillWidth:   true
            label:              qsTr("Voltage Trigger") + (value == 0 ? disabledString : "")
            fact:               controller.getParameterFact(-1, "BATT_CRT_VOLT")
            from:               0
            to:                 100
            majorTickStepSize:  5
        }

        FactSlider {
            Layout.fillWidth:   true
            label:              qsTr("mAh Trigger") + (value == 0 ? disabledString : "")
            fact:               controller.getParameterFact(-1, "BATT_CRT_MAH")
            from:               0
            to:                 30000
            majorTickStepSize:  1000
        }
    }
}
