#pragma once

#include "FirmwarePluginFactory.h"
#include "QGCMAVLink.h"

class PX4FirmwarePlugin;

class PX4FirmwarePluginFactory : public FirmwarePluginFactory
{
    Q_OBJECT

public:
    PX4FirmwarePluginFactory(void);

    QList<QGCMAVLink::FirmwareClass_t>  supportedFirmwareClasses(void) const final;
    FirmwarePlugin*                     firmwarePluginForAutopilot  (MAV_AUTOPILOT autopilotType, MAV_TYPE vehicleType) final;

private:
    PX4FirmwarePlugin*  _pluginInstance;
};
