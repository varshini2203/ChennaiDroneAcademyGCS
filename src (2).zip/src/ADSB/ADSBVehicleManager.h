#pragma once

#include <QtCore/QObject>

#include "ADSB.h"
#include "MAVLinkMessageType.h"

class ADSBTCPLink;
class ADSBVehicle;
class QmlObjectListModel;
class QThread;
class QTimer;
class ADSBVehicleManagerSettings;

class ADSBVehicleManager : public QObject
{
    Q_OBJECT
    Q_MOC_INCLUDE("QmlObjectListModel.h")

    Q_PROPERTY(const QmlObjectListModel *adsbVehicles READ adsbVehicles CONSTANT)

public:
    explicit ADSBVehicleManager(ADSBVehicleManagerSettings *settings, QObject *parent = nullptr);
    ~ADSBVehicleManager();

    static ADSBVehicleManager *instance();

    const QmlObjectListModel *adsbVehicles() const { return _adsbVehicles; }

    void mavlinkMessageReceived(const mavlink_message_t &message);

public slots:
    void adsbVehicleUpdate(const ADSB::VehicleInfo_t &vehicleInfo);

private slots:
    void _cleanupStaleVehicles();
    void _linkError(const QString &errorMsg, bool stopped = false);

private:
    void _start(const QString &hostAddress, quint16 port);
    void _stop();
    void _handleADSBVehicle(const mavlink_message_t &message);

    ADSBVehicleManagerSettings *_adsbSettings = nullptr;
    QTimer *_adsbVehicleCleanupTimer = nullptr;
    QmlObjectListModel *_adsbVehicles = nullptr;

    QMap<uint32_t, ADSBVehicle*> _adsbICAOMap;
    ADSBTCPLink *_adsbTcpLink = nullptr;
    QThread *_adsbTcpLinkThread = nullptr;

    static constexpr uint8_t kMaxTimeSinceLastSeen = 15;
    static constexpr unsigned long kThreadStopTimeoutMs = 5000; ///< max time in ms to wait for the tcp link thread to stop
};
