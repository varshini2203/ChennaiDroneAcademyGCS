#include "ADSBTCPLink.h"
// #include "QGCSensors.h"
#include "QGCLoggingCategory.h"

#include <QtNetwork/QTcpSocket>

QGC_LOGGING_CATEGORY(ADSBTCPLinkLog, "ADSB.ADSBTCPLink")

ADSBTCPLink::ADSBTCPLink(const QString &hostAddress, quint16 port, QObject *parent)
    : QObject(parent)
    , _hostAddress(hostAddress)
    , _port(port)
    , _socket(new QTcpSocket(this))
{
    if (ADSBTCPLinkLog().isDebugEnabled()) {
        (void) connect(_socket, &QTcpSocket::stateChanged, this, [](QTcpSocket::SocketState state) {
            switch (state) {
            case QTcpSocket::UnconnectedState:
                qCDebug(ADSBTCPLinkLog) << "ADSB Socket disconnected";
                break;
            case QTcpSocket::SocketState::ConnectingState:
                qCDebug(ADSBTCPLinkLog) << "ADSB Socket connecting...";
                break;
            case QTcpSocket::SocketState::ConnectedState:
                qCDebug(ADSBTCPLinkLog) << "ADSB Socket connected";
                break;
            case QTcpSocket::SocketState::ClosingState:
                qCDebug(ADSBTCPLinkLog) << "ADSB Socket closing...";
                break;
            default:
                break;
            }
        }, Qt::AutoConnection);
    }

    (void) QObject::connect(_socket, &QTcpSocket::errorOccurred, this, [this](QTcpSocket::SocketError error) {
        qCDebug(ADSBTCPLinkLog) << error << _socket->errorString();
        // TODO: Check if it is a critical error or not and send if the socket is stopped/recoverable
        emit errorOccurred(_socket->errorString(), false);
    }, Qt::AutoConnection);

    (void) connect(_socket, &QTcpSocket::readyRead, this, &ADSBTCPLink::_readBytes);

    // qCDebug(ADSBTCPLinkLog) << Q_FUNC_INFO << this;
}

ADSBTCPLink::~ADSBTCPLink()
{
    // qCDebug(ADSBTCPLinkLog) << Q_FUNC_INFO << this;
}

bool ADSBTCPLink::init()
{
    /* if (!QGCDeviceInfo::isInternetAvailable()) {
        return false;
    } */

    if (_hostAddress.isEmpty()) {
        return false;
    }

    // connectToHost with a hostname resolves DNS asynchronously
    _socket->connectToHost(_hostAddress, _port);

    return true;
}

void ADSBTCPLink::_readBytes()
{
    while (_socket && _socket->canReadLine()) {
        const QByteArray bytes = _socket->readLine();
        _parseLine(QString::fromLocal8Bit(bytes));
    }
}

void ADSBTCPLink::_parseLine(const QString &line)
{
    if (line.size() <= 4) {
        return;
    }

    if (!line.startsWith(QStringLiteral("MSG"))) {
        return;
    }

    const int msgType = line.at(4).digitValue();
    if (msgType == ADSB::Unsupported) {
        qCDebug(ADSBTCPLinkLog) << "ADSB Invalid message type" << msgType;
        return;
    }

    // Skip unsupported mesg types to avoid parsing
    if ((msgType == ADSB::SurfacePosition) || (msgType > ADSB::SurveillanceId)) {
        return;
    }

    qCDebug(ADSBTCPLinkLog) << "ADSB SBS-1" << line;

    const QStringList values = line.split(QChar(','));
    if (values.size() <= 4) {
        return;
    }

    bool icaoOk;
    const uint32_t icaoAddress = values.at(4).toUInt(&icaoOk, 16);
    if (!icaoOk) {
        return;
    }

    ADSB::VehicleInfo_t adsbInfo;
    adsbInfo.icaoAddress = icaoAddress;

    switch (msgType) {
    case ADSB::IdentificationAndCategory:
    case ADSB::SurveillanceAltitude:
    case ADSB::SurveillanceId:
        _parseAndEmitCallsign(adsbInfo, values);
        break;
    case ADSB::AirbornePosition:
        _parseAndEmitLocation(adsbInfo, values);
        break;
    case ADSB::AirborneVelocity:
        _parseAndEmitHeading(adsbInfo, values);
        break;
    default:
        break;
    }
}

void ADSBTCPLink::_parseAndEmitCallsign(ADSB::VehicleInfo_t &adsbInfo, const QStringList &values)
{
    if (values.size() <= 10) {
        return;
    }

    const QString callsign = values.at(10).trimmed();
    if (callsign.isEmpty()) {
        return;
    }

    adsbInfo.callsign = callsign;
    adsbInfo.availableFlags = ADSB::CallsignAvailable;

    emit adsbVehicleUpdate(adsbInfo);
}

void ADSBTCPLink::_parseAndEmitLocation(ADSB::VehicleInfo_t &adsbInfo, const QStringList &values)
{
    if (values.size() <= 19) {
        return;
    }

    // Altitude is either Barometric - based on pressure, in ft
    // or HAE - as reported by GPS - based on WGS84 Ellipsoid, in ft
    // If altitude ends with H, we have HAE
    // There's a slight difference between Barometric alt and HAE, but it would require
    // knowledge about Geoid shape in particular Lat, Lon. It's not worth complicating the code
    QString altitudeStr = values.at(11);
    if (altitudeStr.endsWith('H')) {
        (void) altitudeStr.chop(1);
    }

    bool altOk, latOk, lonOk, alertOk;
    const int modeCAltitude = altitudeStr.toInt(&altOk);
    const double lat = values.at(14).toDouble(&latOk);
    const double lon = values.at(15).toDouble(&lonOk);
    const int alert = values.at(19).toInt(&alertOk);

    if (!altOk || !latOk || !lonOk || !alertOk) {
        return;
    }

    if (qFuzzyIsNull(lat) && qFuzzyIsNull(lon)) {
        return;
    }

    const double altitude = modeCAltitude * 0.3048;
    const QGeoCoordinate location(lat, lon, altitude);

    adsbInfo.location = location;
    adsbInfo.alert = (alert == 1);
    adsbInfo.availableFlags = ADSB::LocationAvailable | ADSB::AltitudeAvailable | ADSB::AlertAvailable;

    emit adsbVehicleUpdate(adsbInfo);
}

void ADSBTCPLink::_parseAndEmitHeading(ADSB::VehicleInfo_t &adsbInfo, const QStringList &values)
{
    if (values.size() <= 13) {
        return;
    }

    bool headingOk = false, speedOk = false;
    const double heading = values.at(13).toDouble(&headingOk);
    const double speedKnots = values.at(12).toDouble(&speedOk);
    if (!headingOk || !speedOk) {
        return;
    }

    adsbInfo.heading = heading;
    adsbInfo.velocity = speedKnots * 0.514444;
    adsbInfo.availableFlags = ADSB::HeadingAvailable | ADSB::VelocityAvailable;

    if (values.size() > 16) {
        bool vertOk = false;
        const double verticalRate = values.at(16).toDouble(&vertOk);
        if (vertOk) {
            adsbInfo.verticalVel = verticalRate * 0.00508;
            adsbInfo.availableFlags |= ADSB::VerticalVelAvailable;
        }
    }

    emit adsbVehicleUpdate(adsbInfo);
}
