#pragma once

#include "VehicleComponent.h"

class APMHeliComponent : public VehicleComponent
{
    Q_OBJECT

public:
    explicit APMHeliComponent(Vehicle *vehicle, AutoPilotPlugin *autopilot, QObject *parent = nullptr);

    QStringList setupCompleteChangedTriggerList() const final { return QStringList(); }

    QString name() const final { return _name; }
    QString description() const final { return tr("Configure swashplate, governor, and rotor parameters."); }
    QString iconResource() const final { return QStringLiteral("/res/helicoptericon.svg"); }
    bool requiresSetup() const final { return false; }
    bool setupComplete() const final { return true; }
    QUrl setupSource() const final { return QUrl::fromUserInput(QStringLiteral("qrc:/qml/QGroundControl/AutoPilotPlugins/APM/APMHeliComponent.qml")); }
    QUrl summaryQmlSource() const final { return QUrl(); }
    bool allowSetupWhileArmed() const final { return true; }

private:
    const QString _name = tr("Heli");
};
