#pragma once

#include "VehicleComponent.h"

class APMLightsComponent : public VehicleComponent
{
    Q_OBJECT

public:
    explicit APMLightsComponent(Vehicle *vehicle, AutoPilotPlugin *autopilot, QObject *parent = nullptr);

    QStringList setupCompleteChangedTriggerList() const final { return QStringList(); }

    QString name() const final { return _name; }
    QString description() const final { return tr("Configure light output channels."); }
    QString iconResource() const final { return QStringLiteral("/qmlimages/LightsComponentIcon.png"); }
    bool requiresSetup() const final { return false; }
    bool setupComplete() const final { return true; }
    QUrl setupSource() const final { return QUrl::fromUserInput(QStringLiteral("qrc:/qml/QGroundControl/AutoPilotPlugins/APM/APMLightsComponent.qml")); }
    QUrl summaryQmlSource() const final { return QUrl::fromUserInput(QStringLiteral("qrc:/qml/QGroundControl/AutoPilotPlugins/APM/APMLightsComponentSummary.qml")); }

private:
    const QString _name = tr("Lights");
};
