#pragma once

#include "VehicleComponent.h"

class PX4TuningComponent : public VehicleComponent
{
    Q_OBJECT

public:
    PX4TuningComponent(Vehicle* vehicle, AutoPilotPlugin* autopilot, QObject* parent = nullptr);

    // Virtuals from VehicleComponent
    QStringList setupCompleteChangedTriggerList(void) const final;

    // Virtuals from VehicleComponent
    QString name(void) const final;
    QString description(void) const final;
    QString iconResource(void) const final;
    bool requiresSetup(void) const final;
    bool setupComplete(void) const final;
    QUrl setupSource(void) const final;
    QUrl summaryQmlSource(void) const final;
    bool allowSetupWhileArmed(void) const final { return true; }
    bool allowSetupWhileFlying(void) const final { return true; }

private:
    const QString   _name;
};
