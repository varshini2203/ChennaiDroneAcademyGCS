import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

import QGroundControl
import QGroundControl.Controls
import QGroundControl.FactControls

ColumnLayout {
    property real _availableHeight:     availableHeight
    property real _availableWidth:      availableWidth

    PIDTuning {
        id:                 pidTuning
        availableWidth:     _availableWidth
        availableHeight:    _availableHeight - pidTuning.y

        property var roll: QtObject {
            property string name: qsTr("Roll")
            property var plot: [
                { name: "Response", value: globals.activeVehicle.roll.value },
                { name: "Setpoint", value: globals.activeVehicle.setpoint.roll.value }
            ]
            property var params: ListModel {
                ListElement {
                    title:          qsTr("Proportional Gain (SC_ROLL_P)")
                    description:    qsTr("Increase for more responsiveness, reduce if the attitude overshoots.")
                    param:          "SC_ROLL_P"
                    min:            1
                    max:            14
                    step:           0.5
                }
            }
        }
        property var pitch: QtObject {
            property string name: qsTr("Pitch")
            property var plot: [
                { name: "Response", value: globals.activeVehicle.pitch.value },
                { name: "Setpoint", value: globals.activeVehicle.setpoint.pitch.value }
            ]
            property var params: ListModel {
                ListElement {
                    title:          qsTr("Proportional Gain (SC_PITCH_P)")
                    description:    qsTr("Increase for more responsiveness, reduce if the attitude overshoots.")
                    param:          "SC_PITCH_P"
                    min:            1
                    max:            14
                    step:           0.5
                }
            }
        }
        property var yaw: QtObject {
            property string name: qsTr("Yaw")
            property var plot: [
                { name: "Response", value: globals.activeVehicle.heading.value },
                { name: "Setpoint", value: globals.activeVehicle.setpoint.yaw.value }
            ]
            property var params: ListModel {
                ListElement {
                    title:          qsTr("Proportional Gain (SC_YAW_P)")
                    description:    qsTr("Increase for more responsiveness, reduce if the attitude overshoots (there is only a setpoint when yaw is fixed, i.e. when centering the stick).")
                    param:          "SC_YAW_P"
                    min:            1
                    max:            5
                    step:           0.1
                }
            }
        }
        title: "Attitude"
        tuningMode: Vehicle.ModeRateAndAttitude
        unit: "deg"
        axis: [ roll, pitch, yaw ]
        showAutoModeChange: true
        showAutoTuning:     false
    }
}
