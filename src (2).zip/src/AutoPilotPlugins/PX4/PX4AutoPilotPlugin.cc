#include "PX4AutoPilotPlugin.h"
#include "PX4AirframeLoader.h"
#include "AppMessages.h"
#include "FlightModesComponent.h"
#include "PX4RadioComponent.h"
#include "PX4TuningComponent.h"
#include "PowerComponent.h"
#include "SafetyComponent.h"
#include "SensorsComponent.h"
#include "ParameterManager.h"
#include "Vehicle.h"
#include "Actuators.h"
#include "ActuatorComponent.h"
#include "QGCLoggingCategory.h"

#include <algorithm>

QGC_LOGGING_CATEGORY(PX4AutoPilotPluginLog, "Vehicle.Actuators.PX4AutoPilotPlugin")

PX4AutoPilotPlugin::PX4AutoPilotPlugin(Vehicle* vehicle, QObject* parent)
    : AutoPilotPlugin(vehicle, parent)
    , _incorrectParameterVersion(false)
    , _airframeComponent(nullptr)
    , _radioComponent(nullptr)
    , _esp8266Component(nullptr)
    , _flightModesComponent(nullptr)
    , _sensorsComponent(nullptr)
    , _safetyComponent(nullptr)
    , _powerComponent(nullptr)
    , _motorComponent(nullptr)
    , _actuatorComponent(nullptr)
    , _tuningComponent(nullptr)
    , _flightBehavior(nullptr)
    , _syslinkComponent(nullptr)
    , _joystickComponent(nullptr)
{
    if (!vehicle) {
        qWarning() << "Internal error";
        return;
    }

    _airframeFacts = new PX4AirframeLoader(this, this);
    Q_CHECK_PTR(_airframeFacts);

    PX4AirframeLoader::loadAirframeMetaData();
}

PX4AutoPilotPlugin::~PX4AutoPilotPlugin()
{
    delete _airframeFacts;
}

const QVariantList& PX4AutoPilotPlugin::vehicleComponents(void)
{
    if (_components.count() == 0 && !_incorrectParameterVersion) {
        if (_vehicle) {
            if (_vehicle->parameterManager()->parametersReady()) {
                _airframeComponent = new AirframeComponent(_vehicle, this, this);
                _airframeComponent->setupTriggerSignals();
                _components.append(QVariant::fromValue(static_cast<VehicleComponent*>(_airframeComponent)));

                if (!_vehicle->hilMode()) {
                    _sensorsComponent = new SensorsComponent(_vehicle, this, this);
                    _sensorsComponent->setupTriggerSignals();
                    _components.append(QVariant::fromValue(static_cast<VehicleComponent*>(_sensorsComponent)));
                }

                _radioComponent = new PX4RadioComponent(_vehicle, this, this);
                _radioComponent->setupTriggerSignals();
                _components.append(QVariant::fromValue(static_cast<VehicleComponent*>(_radioComponent)));

                _flightModesComponent = new FlightModesComponent(_vehicle, this, this);
                _flightModesComponent->setupTriggerSignals();
                _components.append(QVariant::fromValue(static_cast<VehicleComponent*>(_flightModesComponent)));

                _powerComponent = new PowerComponent(_vehicle, this, this);
                _powerComponent->setupTriggerSignals();
                _components.append(QVariant::fromValue(static_cast<VehicleComponent*>(_powerComponent)));

                if (_vehicle->actuators()) {
                    _vehicle->actuators()->init(); // At this point params are loaded, so we can init the actuators
                }

                // Decide between new Actuators page or legacy Motor page
                bool showActuatorsPage = false;
                if (!_vehicle->actuators()) {
                    qCDebug(PX4AutoPilotPluginLog) << "Actuators page will NOT show because:";
                    qCDebug(PX4AutoPilotPluginLog) << "  - Vehicle did not provide actuators metadata via component information";
                } else if (!_vehicle->actuators()->showUi()) {
                    qCDebug(PX4AutoPilotPluginLog) << "Actuators page will NOT show because:";
                    if (!_vehicle->actuators()->isInitialized()) {
                        qCDebug(PX4AutoPilotPluginLog) << "  - Actuators initialization failed:" << _vehicle->actuators()->initializationError();
                    } else {
                        qCDebug(PX4AutoPilotPluginLog) << "  - Condition 'show-ui-if' evaluated to false";
                        qCDebug(PX4AutoPilotPluginLog) << "    (see 'Evaluating [show-ui-if]' log above for details)";
                    }
                } else {
                    showActuatorsPage = true;
                    qCDebug(PX4AutoPilotPluginLog) << "Actuators page WILL show (all conditions passed)";
                }

                if (showActuatorsPage) {
                    _actuatorComponent = new ActuatorComponent(_vehicle, this, this);
                    _actuatorComponent->setupTriggerSignals();
                    _components.append(QVariant::fromValue(static_cast<VehicleComponent*>(_actuatorComponent)));
                } else {
                    qCDebug(PX4AutoPilotPluginLog) << "  → Using legacy Motor page instead";
                    _motorComponent = new MotorComponent(_vehicle, this, this);
                    _motorComponent->setupTriggerSignals();
                    _components.append(QVariant::fromValue(static_cast<VehicleComponent*>(_motorComponent)));
                }

                _safetyComponent = new SafetyComponent(_vehicle, this, this);
                _safetyComponent->setupTriggerSignals();
                _components.append(QVariant::fromValue(static_cast<VehicleComponent*>(_safetyComponent)));

                _tuningComponent = new PX4TuningComponent(_vehicle, this, this);
                _tuningComponent->setupTriggerSignals();
                _components.append(QVariant::fromValue(static_cast<VehicleComponent*>(_tuningComponent)));

                if(_vehicle->parameterManager()->parameterExists(_vehicle->compId(), "SYS_VEHICLE_RESP")) {
                    _flightBehavior = new PX4FlightBehavior(_vehicle, this, this);
                    _flightBehavior->setupTriggerSignals();
                    _components.append(QVariant::fromValue(static_cast<VehicleComponent*>(_flightBehavior)));
                }

                //-- Is there an ESP8266 Connected?
                if(_vehicle->parameterManager()->parameterExists(MAV_COMP_ID_UDP_BRIDGE, "SW_VER")) {
                    _esp8266Component = new ESP8266Component(_vehicle, this, this);
                    _esp8266Component->setupTriggerSignals();
                    _components.append(QVariant::fromValue(static_cast<VehicleComponent*>(_esp8266Component)));
                }

                _joystickComponent = new JoystickComponent(_vehicle, this, this);
                _joystickComponent->setupTriggerSignals();
                _components.append(QVariant::fromValue(static_cast<VehicleComponent*>(_joystickComponent)));

            } else {
                qWarning() << "Call to vehicleCompenents prior to parametersReady";
            }

            if(_vehicle->parameterManager()->parameterExists(_vehicle->compId(), "SLNK_RADIO_CHAN")) {
                _syslinkComponent = new SyslinkComponent(_vehicle, this, this);
                _syslinkComponent->setupTriggerSignals();
                _components.append(QVariant::fromValue(static_cast<VehicleComponent*>(_syslinkComponent)));
            }
        } else {
            qWarning() << "Internal error";
        }

        std::sort(_components.begin(), _components.end(), [](const QVariant &a, const QVariant &b) {
            return a.value<VehicleComponent*>()->name().toLower() < b.value<VehicleComponent*>()->name().toLower();
        });
    }

    return _components;
}

void PX4AutoPilotPlugin::parametersReadyPreChecks(void)
{
    // Base class must be called
    AutoPilotPlugin::parametersReadyPreChecks();

    QString hitlParam("SYS_HITL");
    if (_vehicle->parameterManager()->parameterExists(ParameterManager::defaultComponentId, hitlParam) &&
            _vehicle->parameterManager()->getParameter(ParameterManager::defaultComponentId, hitlParam)->rawValue().toBool()) {
        QGC::showAppMessage(tr("Warning: Hardware In The Loop (HITL) simulation is enabled for this vehicle."));
    }
}

QString PX4AutoPilotPlugin::prerequisiteSetup(VehicleComponent* component) const
{
    bool requiresAirframeCheck = false;

    if (qobject_cast<const FlightModesComponent*>(component)) {
        if (_vehicle->parameterManager()->getParameter(-1, "COM_RC_IN_MODE")->rawValue().toInt() == 1) {
            // No RC input
            return QString();
        } else {
            if (_airframeComponent && !_airframeComponent->setupComplete()) {
                return _airframeComponent->name();
            } else if (_radioComponent && !_radioComponent->setupComplete()) {
                return _radioComponent->name();
            }
        }
    } else if (qobject_cast<const PX4RadioComponent*>(component)) {
        if (_vehicle->parameterManager()->getParameter(-1, "COM_RC_IN_MODE")->rawValue().toInt() != 1) {
            //requiresAirframeCheck = true;
        }
    } else if (qobject_cast<const PX4TuningComponent*>(component)) {
        requiresAirframeCheck = true;
    } else if (qobject_cast<const PowerComponent*>(component)) {
        requiresAirframeCheck = true;
    } else if (qobject_cast<const SafetyComponent*>(component)) {
        requiresAirframeCheck = true;
    } else if (qobject_cast<const SensorsComponent*>(component)) {
        requiresAirframeCheck = true;
    }

    if (requiresAirframeCheck) {
        if (_airframeComponent && !_airframeComponent->setupComplete()) {
            return _airframeComponent->name();
        }
    }

    return QString();
}
