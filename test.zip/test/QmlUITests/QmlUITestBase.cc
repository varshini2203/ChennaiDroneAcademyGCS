#include "QmlUITestBase.h"

#include <QtCore/QCoreApplication>
#include <QtCore/QElapsedTimer>
#include <QtCore/QEventLoop>
#include <QtCore/QRegularExpression>
#include <QtCore/QScopeGuard>
#include <QtCore/QVariant>
#include <QtCore/QtMath>
#include <QtQml/QQmlApplicationEngine>
#include <QtQml/QQmlIncubationController>
#include <QtQuick/QQuickItem>
#include <QtQuick/QQuickWindow>
#include <QtQuick/QSGRendererInterface>
#include <QtQuickControls2/QQuickStyle>
#include <QtTest/QSignalSpy>
#include <QtTest/QTest>

#include "AppSettings.h"
#include "ColoredSvgImageProvider.h"
#include "MAVLinkProtocol.h"
#include "MockLink.h"
#include "MultiVehicleManager.h"
#include "QGCApplication.h"
#include "QGCCorePlugin.h"
#include "QGCFileDialogController.h"
#include "QGCImageProvider.h"
#include "SettingsManager.h"
#include "Vehicle.h"

// Bounded real-time window for render/GC/deferred-delete settle drains during UI teardown.
// These have no observable completion condition in offscreen mode (the render loop never
// self-pumps), so we drain events for a fixed, minimal interval instead.
static constexpr int kSettleDrainMs = 100;

static QQuickItem* findVisibleItemImmediate(QQuickItem* root, const QString& objectName)
{
    if (!root || !root->isVisible()) {
        return nullptr;
    }
    if (root->objectName() == objectName) {
        return root;
    }
    const auto children = root->childItems();
    for (auto* child : children) {
        if (auto* found = findVisibleItemImmediate(child, objectName)) {
            return found;
        }
    }
    return nullptr;
}

QQuickItem* QmlUITestBase::findVisibleItem(QQuickItem* root, const QString& objectName, int timeoutMs)
{
    constexpr int pollIntervalMs = 50;
    int elapsed = 0;
    while (elapsed <= timeoutMs) {
        if (auto* item = findVisibleItemImmediate(root, objectName)) {
            return item;
        }
        if (elapsed >= timeoutMs) {
            break;
        }
        QTest::qWait(pollIntervalMs);
        elapsed += pollIntervalMs;
    }
    return nullptr;
}

void QmlUITestBase::startUI()
{
    // Initialise subsystems needed for the full QML UI
    // setStyle() must only be called once per process; subsequent calls after
    // any QML engine has loaded produce an "must be called before loading QML"
    // warning that would trip the strict-mode log check.
    static bool s_styleSet = false;
    if (!s_styleSet) {
        QQuickStyle::setStyle("Basic");
        s_styleSet = true;
    }
    QGCCorePlugin::instance()->init();
    MAVLinkProtocol::instance()->init();
    MultiVehicleManager::instance()->init();

    // Suppress first-run prompts so they don't block the UI
    AppSettings* appSettings = SettingsManager::instance()->appSettings();
    const QList<int> promptIds = QGCCorePlugin::instance()->firstRunPromptStdIds();
    for (int id : promptIds) {
        appSettings->firstRunPromptIdsMarkIdAsShown(id);
    }

    QVERIFY2(QGCCorePlugin::instance(), "Core plugin not available");
    // Custom builds may default advanced UI off; these tests exercise the full UI.
    QGCCorePlugin::instance()->setProperty("showAdvancedUI", true);
    QVERIFY2(QGCCorePlugin::instance()->showAdvancedUI(), "Test requires Advanced UI mode");

    // Ignore benign Qt platform warnings that cannot be avoided in offscreen mode
    ignoreLogMessage("default", QtWarningMsg,
                     QRegularExpression(QStringLiteral("This plugin does not support propagateSizeHints")));
    ignoreLogMessage("qt.qpa.fonts", QtWarningMsg,
                     QRegularExpression(QStringLiteral("Populating font family aliases")));
    ignoreLogMessage("default", QtWarningMsg, QRegularExpression(QStringLiteral("QRhiGles2")));
    // Async QML incubation rides QQuickWindow's render-loop controller, which never pumps in
    // offscreen mode, so a component still incubating at engine teardown logs this.
    ignoreLogMessage("default", QtInfoMsg,
                     QRegularExpression(QStringLiteral("Object or context destroyed during incubation")));
    // Offscreen incubation can leave an item incubating at teardown; the drain is best-effort.
    ignoreLogMessage("default", QtWarningMsg,
                     QRegularExpression(QStringLiteral("in the process of being created at engine destruction")));

    // Slow headless/software-GL runners can leave async-incubated QML items still
    // creating when the engine is torn down (destroyUIEngine drains best-effort but
    // cannot guarantee completion). Benign at shutdown, so ignore it rather than fail
    // strict mode on a timing artifact.
    ignoreLogMessage("default", QtWarningMsg,
                     QRegularExpression(QStringLiteral("items in the process of being created at engine destruction")));

#ifdef QT_DEBUG
    // Debug builds on macOS are ad-hoc signed with an unbound Info.plist, so
    // macOS never shows the camera permission dialog and silently denies access.
    ignoreLogMessage("default", QtWarningMsg, QRegularExpression(QStringLiteral("Access to camera not granted")));
#endif

    _engine = QGCCorePlugin::instance()->createQmlApplicationEngine(this);
    QVERIFY(_engine);

    _engine->addImageProvider(QStringLiteral("QGCImages"), new QGCImageProvider());
    _engine->addImageProvider(QLatin1String(ColoredSvgImageProvider::ProviderId), new ColoredSvgImageProvider());

    _engine->load(QUrl(QStringLiteral("qrc:/qml/QGroundControl/MainWindow.qml")));
    QVERIFY(!_engine->rootObjects().isEmpty());

    // Register the engine with the app so showAppMessage() reaches this MainWindow
    // and app message dialogs are shown for real during UI tests.
    qgcApp()->setQmlAppEngine(_engine);

    _window = qobject_cast<QQuickWindow*>(_engine->rootObjects().first());
    QVERIFY(_window);

    QVERIFY(QTest::qWaitForWindowExposed(_window));

    _viewDelay = (qApp->platformName() != QLatin1String("offscreen")) ? 700 : 0;
    _pageDelay = (qApp->platformName() != QLatin1String("offscreen")) ? 400 : 0;

    _rootItem = _window->contentItem();
}

void QmlUITestBase::closeUIWindow()
{
    if (_window) {
        _window->close();
        (void) QTest::qWaitFor([this] { return !_window->isVisible(); }, TestTimeout::shortMs());
        // No observable post-close condition: this is a bounded render/deferred-delete settle
        // drain (offscreen render loop never self-pumps). Drain real-time so queued
        // deleteLater()/timer events fire before the engine is torn down.
        QElapsedTimer settle;
        settle.start();
        while (settle.elapsed() < kSettleDrainMs) {
            QCoreApplication::processEvents(QEventLoop::AllEvents, 20);
        }
    }
}

void QmlUITestBase::destroyUIEngine()
{
    if (_engine) {
        // Async incubation rides QQuickWindow's render-loop controller, which never
        // pumps in offscreen mode, so pending incubators stall mid-creation and the
        // engine warns "items still being created at engine destruction". Pump the
        // controller directly until it drains so teardown is clean.
        if (QQmlIncubationController* controller = _engine->incubationController()) {
            QElapsedTimer drainTimer;
            drainTimer.start();
            while ((controller->incubatingObjectCount() > 0) && (drainTimer.elapsed() < 2000)) {
                controller->incubateFor(50);
                QCoreApplication::processEvents();
            }
        }

        // Give asynchronous QML item creation/destruction a brief drain window
        // before engine teardown to avoid strict-mode warnings at shutdown.
        // No observable condition: bounded GC/event settle drain so the engine releases
        // references to C++ singletons before teardown (see comment above).
        QElapsedTimer gcSettle;
        gcSettle.start();
        while (gcSettle.elapsed() < kSettleDrainMs) {
            _engine->collectGarbage();
            QCoreApplication::processEvents(QEventLoop::AllEvents, 10);
        }

        // Force GC and event processing so QML releases references to C++ singletons
        // (e.g. SettingsFacts) before the engine is destroyed.  Without this,
        // QQmlData attached to those objects fires stale binding updates during
        // Q_APPLICATION_STATIC teardown and crashes.
        _engine->collectGarbage();
        QCoreApplication::processEvents();
        _engine->clearComponentCache();
        QCoreApplication::processEvents();

        // Destroy the root window while the engine/context are still alive so a Loader
        // stuck mid-incubation is cancelled here instead of crashing engine teardown.
        delete _window;
        _window = nullptr;
        QCoreApplication::processEvents();
    }
    qgcApp()->setQmlAppEngine(nullptr);
    QGCCorePlugin::instance()->destroyQmlApplicationEngine(_engine);
    _engine   = nullptr;
    _window   = nullptr;
    _rootItem = nullptr;
    QCoreApplication::processEvents();
}

void QmlUITestBase::stopUI()
{
    closeUIWindow();
    destroyUIEngine();
}

void QmlUITestBase::_verifyFileDialogTestHookConsumed()
{
    if (QGCFileDialogController::testHookArmed()) {
        QGCFileDialogController::takeTestNextFile();  // clear so later tests aren't contaminated
        QTest::qFail("file dialog test hook was armed but never consumed by a dialog", __FILE__, __LINE__);
    }
}

bool QmlUITestBase::clickButton(const QString& objectName)
{
    QQuickItem* btn = findVisibleItem(_rootItem, objectName);
    if (!btn) {
        return false;
    }
    return _clickItemAt(btn, 0.5, 0.5, objectName);
}

bool QmlUITestBase::_clickItemAt(QQuickItem* item, qreal fractionX, qreal fractionY, const QString& objectName)
{
    const QPointer<QQuickItem> guarded(item);

    // A freshly-visible item can report a stale position: positioners lay out
    // their children in a polish pass that has not necessarily run yet (e.g. layer
    // switcher choices fading in inside a RightToLeft Row report the Row origin
    // until polished). Clicking a stale position silently lands on the wrong item.
    // Flush pending polish up the ancestor chain, then require the mapped scene
    // position to be identical across two consecutive event-loop passes so
    // animated reflows have finished too.
    const auto scenePoint = [&]() -> QPointF {
        for (QQuickItem* ancestor = guarded; ancestor; ancestor = ancestor->parentItem()) {
            ancestor->ensurePolished();
        }
        return guarded->mapToScene(QPointF(guarded->width() * fractionX, guarded->height() * fractionY));
    };
    QPointF lastPos(qQNaN(), qQNaN());
    const bool settled = waitForCondition(
        [&] {
            if (!guarded) {
                return false;
            }
            const QPointF pos = scenePoint();
            const bool stable = (pos == lastPos);
            lastPos = pos;
            return stable;
        },
        TestTimeout::shortMs(), QStringLiteral("%1 position settled").arg(objectName));
    if (!guarded) {
        QTest::qFail(qPrintable(QStringLiteral("%1 destroyed while waiting to click it").arg(objectName)), __FILE__,
                     __LINE__);
        return false;
    }
    if (!settled) {
        return false;  // waitForCondition already logged the timeout
    }

    // QTest::mouseClick warns and drops clicks outside the window (valid range is
    // 0..width-1 / 0..height-1); a centre exactly on the bottom edge is outside.
    // Fail loudly here instead of letting the dropped click surface as an
    // unrelated failure (or silent no-op) later in the test. Validate in
    // floating-point space and convert by truncation: rounding could push an
    // in-window position like x=799.6 in an 800px window to the invalid x=800.
    const QPointF scenePos = scenePoint();
    if (scenePos.x() < 0 || scenePos.x() >= _window->width() || scenePos.y() < 0 || scenePos.y() >= _window->height()) {
        QTest::qFail(qPrintable(QStringLiteral("%1 click point (%2, %3) is outside the window (%4x%5)")
                                    .arg(objectName)
                                    .arg(scenePos.x())
                                    .arg(scenePos.y())
                                    .arg(_window->width())
                                    .arg(_window->height())),
                     __FILE__, __LINE__);
        return false;
    }
    const QPoint clickPoint(qFloor(scenePos.x()), qFloor(scenePos.y()));

    QTest::mouseClick(_window, Qt::LeftButton, Qt::NoModifier, clickPoint);
    return true;
}

bool QmlUITestBase::clickItemFraction(const QString& objectName, qreal fractionX, qreal fractionY)
{
    // Fail loudly on nonsense fractions rather than silently clicking outside
    // the item (which would surface as an unrelated failure later in the test)
    if (!qIsFinite(fractionX) || !qIsFinite(fractionY) || (fractionX < 0) || (fractionX > 1) || (fractionY < 0) ||
        (fractionY > 1)) {
        QTest::qFail(
            qPrintable(
                QStringLiteral("clickItemFraction: fractions out of [0,1]: (%1, %2)").arg(fractionX).arg(fractionY)),
            __FILE__, __LINE__);
        return false;
    }
    QQuickItem* item = findVisibleItem(_rootItem, objectName);
    if (!item) {
        return false;
    }
    return _clickItemAt(item, fractionX, fractionY, objectName);
}

QQuickItem* QmlUITestBase::findVisibleItemScrolled(const QString& objectName, const QString& flickableObjectName)
{
    // Fast path: delegate already instantiated somewhere in the visual tree
    QQuickItem* item = findVisibleItem(_rootItem, objectName, 500);
    if (item) {
        return scrollIntoView(item, flickableObjectName) ? item : nullptr;
    }

    QQuickItem* flickable = findVisibleItem(_rootItem, flickableObjectName);
    if (!flickable) {
        return nullptr;
    }

    // Virtualized delegates only exist for rows near the viewport. Step the
    // flickable through its content range to force the target row to instantiate.
    const double viewportHeight = flickable->height();
    if (viewportHeight <= 0) {
        return nullptr;  // not laid out yet: stepping cannot advance
    }
    // Iteration cap guards against content that grows as delegates instantiate
    constexpr int kMaxScrollSteps = 100;
    double y = 0;
    for (int step = 0; step < kMaxScrollSteps; step++, y += viewportHeight) {
        const double maxContentY = qMax(0.0, flickable->property("contentHeight").toDouble() - viewportHeight);
        const double clampedY = qMin(y, maxContentY);
        flickable->setProperty("contentY", clampedY);
        item = findVisibleItem(_rootItem, objectName, 100);
        if (item) {
            return scrollIntoView(item, flickableObjectName) ? item : nullptr;
        }
        if (clampedY >= maxContentY) {
            break;
        }
    }
    return nullptr;
}

bool QmlUITestBase::clickButtonScrolled(const QString& objectName, const QString& flickableObjectName)
{
    if (!findVisibleItemScrolled(objectName, flickableObjectName)) {
        return false;
    }
    return clickButton(objectName);
}

bool QmlUITestBase::clickToolSelectDropdownButton(const QString& viewObjectName, int timeoutMs)
{
    if (!clickButton(QStringLiteral("toolbar_qgcLogo"))) {
        QTest::qFail("Failed to click Q logo button", __FILE__, __LINE__);
        return false;
    }
    if (!findVisibleItem(_rootItem, viewObjectName, timeoutMs)) {
        QTest::qFail(qPrintable(QStringLiteral("Tool select dropdown button not found: %1").arg(viewObjectName)),
                     __FILE__, __LINE__);
        return false;
    }
    if (!clickButton(viewObjectName)) {
        QTest::qFail(qPrintable(QStringLiteral("Failed to click tool select dropdown button: %1").arg(viewObjectName)),
                     __FILE__, __LINE__);
        return false;
    }
    return true;
}

// Recursively search the visible item tree for an item with the given
// objectName whose "text" property contains the given substring. Used to
// locate a specific dialog by its title label.
static QQuickItem* _findVisibleItemWithText(QQuickItem* root, const QString& objectName, const QString& textSubstring)
{
    if (!root || !root->isVisible()) {
        return nullptr;
    }
    if (root->objectName() == objectName) {
        const QVariant textProp = root->property("text");
        if (textProp.isValid() && textProp.toString().contains(textSubstring)) {
            return root;
        }
    }
    const auto children = root->childItems();
    for (auto* child : children) {
        if (auto* found = _findVisibleItemWithText(child, objectName, textSubstring)) {
            return found;
        }
    }
    return nullptr;
}

bool QmlUITestBase::dialogVisible(const QString& titleSubstring)
{
    return _findVisibleItemWithText(_rootItem, QStringLiteral("popupDialog_title"), titleSubstring) != nullptr;
}

bool QmlUITestBase::waitForDialog(const QString& titleSubstring, int timeoutMs)
{
    return waitForCondition([this, &titleSubstring] { return dialogVisible(titleSubstring); }, timeoutMs,
                            QStringLiteral("dialog '%1'").arg(titleSubstring));
}

bool QmlUITestBase::acceptDialog(int timeoutMs)
{
    if (!findVisibleItem(_rootItem, QStringLiteral("popupDialog_acceptButton"), timeoutMs)) {
        return false;
    }
    return clickButton(QStringLiteral("popupDialog_acceptButton"));
}

bool QmlUITestBase::rejectDialog(int timeoutMs)
{
    if (!findVisibleItem(_rootItem, QStringLiteral("popupDialog_rejectButton"), timeoutMs)) {
        return false;
    }
    return clickButton(QStringLiteral("popupDialog_rejectButton"));
}

// Format a property value for failure messages: quote strings, otherwise use
// QVariant's string form ("true"/"false" for bools).
static QString _displayValue(const QVariant& value)
{
    if (value.typeId() == QMetaType::QString) {
        return QStringLiteral("'%1'").arg(value.toString());
    }
    return value.toString();
}

bool QmlUITestBase::_verifyItemProperty(const QString& objectName, const char* propertyName,
                                        const QVariant& expectedValue, const QString& context)
{
    // Item discovery is as asynchronous as state propagation (view transitions,
    // Loaders); poll for the item with the same ceiling as the state check.
    // findVisibleItem returns immediately once the item exists.
    QQuickItem* item = findVisibleItem(_rootItem, objectName, 2000);
    if (!item) {
        QTest::qFail(qPrintable(QStringLiteral("%1: item not found: %2").arg(context, objectName)), __FILE__, __LINE__);
        return false;
    }

    // An invalid QVariant silently converts to false/"", which would make a
    // false/empty expected value pass vacuously on an item without the property.
    if (!item->property(propertyName).isValid()) {
        QTest::qFail(
            qPrintable(
                QStringLiteral("%1: %2 has no '%3' property").arg(context, objectName, QLatin1String(propertyName))),
            __FILE__, __LINE__);
        return false;
    }

    // Guard against the item being destroyed while waiting (e.g. view rebuilds)
    const QPointer<QQuickItem> guardedItem(item);

    // State changes propagate through bindings; allow them to settle
    const bool matched = waitForCondition(
        [guardedItem, propertyName, expectedValue] {
            return guardedItem && (guardedItem->property(propertyName) == expectedValue);
        },
        2000, QStringLiteral("%1 %2 == %3").arg(objectName, QLatin1String(propertyName), _displayValue(expectedValue)));
    if (!matched) {
        QTest::qFail(qPrintable(QStringLiteral("%1: %2 expected %3=%4 but was %5")
                                    .arg(context, objectName, QLatin1String(propertyName), _displayValue(expectedValue),
                                         guardedItem ? _displayValue(guardedItem->property(propertyName))
                                                     : QStringLiteral("<item destroyed>"))),
                     __FILE__, __LINE__);
        return false;
    }
    return true;
}

bool QmlUITestBase::verifyEnabled(const QString& objectName, bool expectedEnabled, const QString& context)
{
    return _verifyItemProperty(objectName, "enabled", expectedEnabled, context);
}

bool QmlUITestBase::verifyProperty(const QString& objectName, const char* propertyName, const QVariant& expectedValue,
                                   const QString& context)
{
    return _verifyItemProperty(objectName, propertyName, expectedValue, context);
}

bool QmlUITestBase::verifyVisibility(const QString& objectName, bool expectedVisible, const QString& context)
{
    const bool result = waitForCondition(
        [this, objectName, expectedVisible] {
            return (findVisibleItem(_rootItem, objectName, 0) != nullptr) == expectedVisible;
        },
        2000,
        QStringLiteral("%1 %2").arg(objectName,
                                    expectedVisible ? QStringLiteral("visible") : QStringLiteral("absent")));
    if (!result) {
        QTest::qFail(qPrintable(QStringLiteral("%1: %2 expected %3")
                                    .arg(context, objectName,
                                         expectedVisible ? QStringLiteral("visible") : QStringLiteral("absent"))),
                     __FILE__, __LINE__);
    }
    return result;
}

bool QmlUITestBase::verifyPrimary(const QString& objectName, bool expectedPrimary, const QString& context)
{
    return _verifyItemProperty(objectName, "primary", expectedPrimary, context);
}

// On Linux CI (xvfb + llvmpipe) CMake gives View3D tests a real RHI OpenGL
// backend so View3D genuinely renders. Where the harness still forces the
// software backend (e.g. macOS offscreen), View3D cannot render — the scene
// graph objects still instantiate — and Qt emits two known warnings when a
// frame renders a View3D. In strict mode, assert those warnings actually
// occur (rather than silently ignoring them) so a Qt behavior change is
// caught; ignore absorbs nondeterministic repeats from subsequent render
// passes. Detection must use the live window's renderer interface:
// QQuickWindow::graphicsApi() does not reflect the QT_QUICK_BACKEND=software
// adaptation.
std::optional<bool> QmlUITestBase::expectSoftwareBackendWarnings(bool strict)
{
    if (!_window) {
        return std::nullopt;  // called outside the startUI()/stopUI() window
    }
    const QSGRendererInterface* const rif = _window->rendererInterface();
    if (!rif) {
        return std::nullopt;
    }
    const bool rhiBased = QSGRendererInterface::isApiRhiBased(rif->graphicsApi());
    if (!rhiBased) {
        if (strict) {
            // expect asserts each warning occurs at least once (verified at the
            // end of the test); each verify consumes only ONE captured message,
            // and Qt repeats the pair a nondeterministic number of times (once
            // per View3D init/render pass), so ignore absorbs the surplus repeats
            // that would otherwise fail strict mode.
            expectLogMessage("default", QtWarningMsg, QRegularExpression(QStringLiteral("isApiRhiBased")));
            expectLogMessage("default", QtWarningMsg,
                             QRegularExpression(QStringLiteral("Qt Quick 3D is not functional")));
        }
        ignoreLogMessage("default", QtWarningMsg, QRegularExpression(QStringLiteral("isApiRhiBased")));
        ignoreLogMessage("default", QtWarningMsg, QRegularExpression(QStringLiteral("Qt Quick 3D is not functional")));
    }
    return rhiBased;
}

bool QmlUITestBase::verifyChecked(const QString& objectName, bool expectedChecked, const QString& context)
{
    return _verifyItemProperty(objectName, "checked", expectedChecked, context);
}

bool QmlUITestBase::verifyText(const QString& objectName, const QString& expectedText, const QString& context)
{
    return _verifyItemProperty(objectName, "text", expectedText, context);
}

bool QmlUITestBase::scrollIntoView(QQuickItem* item, const QString& flickableObjectName)
{
    if (!item || !_rootItem || !_window) {
        return false;
    }

    QQuickItem* flickable = findVisibleItem(_rootItem, flickableObjectName);
    if (!flickable) {
        return false;
    }

    // Scroll until the item's centre sits inside the flickable's clickable region
    // and stays there. A single scroll is not enough: expand/collapse reflows and
    // pending polish passes can shift content after contentY is applied (a row that
    // was centred can end up hanging past the window edge where clicks are dropped).
    // Each poll flushes polish, re-checks containment, and re-issues the scroll if
    // the item has drifted out again; success requires the centre to be stable in
    // the clickable region across two consecutive event-loop passes.
    //
    // The clickable region is the viewport clipped to the window, inset by 1px
    // because QRectF::contains includes edges: a centre exactly on the window's
    // bottom edge (y == height) maps to a click outside the window's valid
    // 0..height-1 range.
    const QPointer<QQuickItem> guardedItem(item);
    const QPointer<QQuickItem> guardedFlickable(flickable);
    QPointF lastCenter(qQNaN(), qQNaN());
    const bool settled = waitForCondition(
        [&] {
            if (!guardedItem || !guardedFlickable) {
                return false;
            }
            for (QQuickItem* ancestor = guardedItem; ancestor; ancestor = ancestor->parentItem()) {
                ancestor->ensurePolished();
            }
            const QPointF sceneCenter =
                guardedItem->mapToScene(QPointF(guardedItem->width() / 2, guardedItem->height() / 2));
            const QRectF flickableViewport(guardedFlickable->mapToScene(QPointF(0, 0)),
                                           QSizeF(guardedFlickable->width(), guardedFlickable->height()));
            const QRectF windowRect(0, 0, _window->width(), _window->height());
            const QRectF clickableViewport = flickableViewport.intersected(windowRect).adjusted(1, 1, -1, -1);

            const bool stable = (sceneCenter == lastCenter);
            lastCenter = sceneCenter;
            if (clickableViewport.contains(sceneCenter)) {
                return stable;
            }

            // mapToItem gives a viewport-relative position (already offset by contentY).
            // Add current contentY to get the absolute content-space position, then
            // target a contentY that centres the item in the flickable.
            const QPointF itemInFlickable = guardedItem->mapToItem(guardedFlickable, QPointF(0, 0));
            const double currentContentY = guardedFlickable->property("contentY").toDouble();
            const double absoluteY = itemInFlickable.y() + currentContentY;
            const double targetY = absoluteY + guardedItem->height() / 2.0 - guardedFlickable->height() / 2.0;
            const double maxContentY =
                guardedFlickable->property("contentHeight").toDouble() - guardedFlickable->height();
            guardedFlickable->setProperty("contentY", qBound(0.0, targetY, qMax(0.0, maxContentY)));
            return false;
        },
        TestTimeout::shortMs(), QStringLiteral("scrollIntoView settled"));
    if (!settled) {
        // Record a test failure (as the pre-refactor QTRY_VERIFY_WITH_TIMEOUT did)
        // rather than letting a click on a still-clipped item surface as a
        // harder-to-diagnose failure later in the test.
        QTest::qFail(
            qPrintable(
                QStringLiteral("scrollIntoView: item never settled inside flickable %1").arg(flickableObjectName)),
            __FILE__, __LINE__);
        return false;
    }
    return true;
}

void QmlUITestBase::runWithMockLink(const std::function<MockLink*()>& factory,
                                    const std::function<void(QPointer<MockLink>, Vehicle*)>& body)
{
    startUI();
    if (QTest::currentTestFailed())
        return;

    Vehicle* vehicle = nullptr;
    QPointer<MockLink> mockLink = connectMockLinkAndWaitReady(factory, vehicle);
    if (!mockLink)
        return;

    const auto cleanup = qScopeGuard([&] {
        disconnectMockLink(mockLink);
        closeUIWindow();
        destroyUIEngine();
    });

    body(mockLink, vehicle);
}

void QmlUITestBase::disconnectMockLink(QPointer<MockLink> mockLink)
{
    if (!mockLink)
        return;

    QSignalSpy spyDisconnect(MultiVehicleManager::instance(), &MultiVehicleManager::activeVehicleChanged);
    mockLink->disconnect();
    if (spyDisconnect.isValid()) {
        (void) waitForSignal(spyDisconnect, 5000, QStringLiteral("activeVehicleChanged"));
    }
}

QPointer<MockLink> QmlUITestBase::connectMockLinkAndWaitReady(const std::function<MockLink*()>& factory,
                                                              Vehicle*& vehicleOut)
{
    vehicleOut = nullptr;

    QSignalSpy spyVehicle(MultiVehicleManager::instance(), &MultiVehicleManager::activeVehicleChanged);
    if (!spyVehicle.isValid()) {
        QTest::qFail("Failed to create spy for activeVehicleChanged", __FILE__, __LINE__);
        return {};
    }

    QPointer<MockLink> mockLink = factory();
    if (!mockLink) {
        QTest::qFail("Failed to start MockLink", __FILE__, __LINE__);
        return {};
    }

    // Helper: disconnect the MockLink and return {} so callers never receive a
    // live link they cannot clean up (the caller's qScopeGuard is not yet active).
    const auto failAndDisconnect = [&](const char* msg) -> QPointer<MockLink> {
        QTest::qFail(msg, __FILE__, __LINE__);
        mockLink->disconnect();
        return {};
    };

    if (!waitForSignal(spyVehicle, 10000, QStringLiteral("activeVehicleChanged"))) {
        return failAndDisconnect("Timeout waiting for vehicle connection");
    }

    Vehicle* vehicle = MultiVehicleManager::instance()->activeVehicle();
    if (!vehicle) {
        return failAndDisconnect("No active vehicle after MockLink connection");
    }

    QSignalSpy spyConnect(vehicle, &Vehicle::initialConnectComplete);
    if (!spyConnect.isValid()) {
        return failAndDisconnect("Failed to create spy for initialConnectComplete");
    }
    if (!vehicle->isInitialConnectComplete()) {
        if (!waitForSignal(spyConnect, 10000, QStringLiteral("initialConnectComplete"))) {
            return failAndDisconnect("Timeout waiting for initial connect");
        }
    }

    QSignalSpy spyParamsReady(MultiVehicleManager::instance(),
                              &MultiVehicleManager::parameterReadyVehicleAvailableChanged);
    if (!spyParamsReady.isValid()) {
        return failAndDisconnect("Failed to create spy for parameterReadyVehicleAvailableChanged");
    }
    if (!MultiVehicleManager::instance()->parameterReadyVehicleAvailable()) {
        if (!waitForSignal(spyParamsReady, 15000, QStringLiteral("parameterReadyVehicleAvailableChanged"))) {
            return failAndDisconnect("Timeout waiting for parameters to be ready");
        }
    }
    if (!MultiVehicleManager::instance()->parameterReadyVehicleAvailable()) {
        return failAndDisconnect("Parameters should be ready after signal");
    }

    vehicleOut = vehicle;
    return mockLink;
}
