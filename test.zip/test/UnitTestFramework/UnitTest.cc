#include "UnitTest.h"

#include <QtCore/QCoreApplication>
#include <QtCore/QDateTime>
#include <QtCore/QDir>
#include <QtCore/QElapsedTimer>
#include <QtCore/QEvent>
#include <QtCore/QHash>
#include <QtCore/QSet>
#include <QtCore/QSettings>
#include <QtCore/QStandardPaths>
#include <QtCore/QRegularExpression>
#include <QtCore/QScopeGuard>
#include <QtTest/QSignalSpy>
#include <QtTest/QTest>

#include <atomic>
#include <cstring>
#include <iterator>

#include "AppSettings.h"
#include "AutoPilotPlugin.h"
#include "FirmwarePluginManager.h"
#include "LinkManager.h"
#include "LogEntry.h"
#include "MultiVehicleManager.h"
#include "QGCApplication.h"
#include "LogManager.h"
#include "QGCLoggingCategory.h"
#include "QmlObjectListModel.h"
#include "SettingsManager.h"
#include "Vehicle.h"
#include "VehicleComponent.h"

struct UnitTest::ExpectedLogMessages
{
    struct Entry
    {
        LogEntry::Level level;
        QRegularExpression pattern;
        QString category;
    };

    struct PendingExpectation
    {
        Entry entry;
        int startIndex = 0;
    };

    QList<Entry> ignored;
    QList<PendingExpectation> pending;
    QSet<int> consumedMessageIndices;
};

QGC_LOGGING_CATEGORY(UnitTestLog, "Test.UnitTest")

// ============================================================================
// TestContext Implementation
// ============================================================================

QStringList& TestContext::stack()
{
    // QTest runs test functions sequentially on the main thread — no TLS needed.
    static QStringList s_stack;
    return s_stack;
}

TestContext::TestContext(const QString& context)
{
    push(context);
}

TestContext::~TestContext()
{
    pop();
}

QString TestContext::current()
{
    const QStringList& s = stack();
    if (s.isEmpty()) {
        return QString();
    }
    return s.join(QStringLiteral(" > "));
}

void TestContext::push(const QString& context)
{
    stack().append(context);
}

void TestContext::pop()
{
    if (!stack().isEmpty()) {
        stack().removeLast();
    }
}

// ============================================================================
// TestDebug Implementation
// ============================================================================

QStringList& TestDebug::messages()
{
    static QStringList s_messages;
    return s_messages;
}

bool& TestDebug::verbose()
{
    static bool s_verbose = qEnvironmentVariableIsSet("QGC_TEST_VERBOSE");
    return s_verbose;
}

void TestDebug::log(const QString& message)
{
    messages().append(message);
    while (messages().size() > kMaxBufferedMessages) {
        messages().removeFirst();
    }

    if (isVerbose()) {
        qCDebug(UnitTestLog) << message;
    }
}

void TestDebug::setVerbose(bool v)
{
    verbose() = v;
}

bool TestDebug::isVerbose()
{
    return verbose();
}

QStringList TestDebug::recentMessages()
{
    return messages();
}

void TestDebug::clearMessages()
{
    messages().clear();
}

namespace {
constexpr int kFileCompareBufferSize = 8192;
constexpr int kMaxTimeoutDebugMessages = 10;

// Single source of truth for label name/value mapping
struct LabelMapping
{
    TestLabel label;
    const char* name;
};

// clang-format off
constexpr LabelMapping kLabelMappings[] = {
    {TestLabel::Unit,           "unit"},
    {TestLabel::Integration,    "integration"},
    {TestLabel::Vehicle,        "vehicle"},
    {TestLabel::MissionManager, "missionmanager"},
    {TestLabel::Comms,          "comms"},
    {TestLabel::Utilities,      "utilities"},
    {TestLabel::Slow,           "slow"},
    {TestLabel::Network,        "network"},
    {TestLabel::Serial,         "serial"},
    {TestLabel::Joystick,       "joystick"},
    {TestLabel::AnalyzeView,    "analyzeview"},
    {TestLabel::Terrain,        "terrain"},
};
// clang-format on

// Build hash map lazily for O(1) string→label lookup
const QHash<QString, TestLabel>& labelMap()
{
    static const QHash<QString, TestLabel> map = []() {
        QHash<QString, TestLabel> m;
        for (const auto& mapping : kLabelMappings) {
            m.insert(QString::fromLatin1(mapping.name), mapping.label);
        }
        return m;
    }();
    return map;
}

QString currentTestName()
{
    const char* functionName = QTest::currentTestFunction();
    const char* dataTag = QTest::currentDataTag();

    QString testName = functionName ? QString::fromLatin1(functionName) : QStringLiteral("<unknown>");
    if (dataTag && dataTag[0] != '\0') {
        testName += QStringLiteral(" [") + QString::fromLatin1(dataTag) + QStringLiteral("]");
    }

    return testName;
}

void logRecentDebugMessages(const char* header)
{
    const QStringList debugMessages = TestDebug::recentMessages();
    if (debugMessages.isEmpty()) {
        return;
    }

    qCWarning(UnitTestLog) << header;

    const int startIndex = qMax(0, debugMessages.size() - kMaxTimeoutDebugMessages);
    for (int i = startIndex; i < debugMessages.size(); ++i) {
        qCWarning(UnitTestLog) << "  " << debugMessages.at(i);
    }
}

}  // anonymous namespace

// ============================================================================
// Label Conversion Functions
// ============================================================================

TestLabel labelFromString(const QString& name)
{
    return labelMap().value(name.toLower().trimmed(), TestLabel::None);
}

QString labelToString(TestLabel label)
{
    if (label == TestLabel::None) {
        return QStringLiteral("none");
    }
    for (const auto& mapping : kLabelMappings) {
        if (mapping.label == label) {
            return QString::fromLatin1(mapping.name);
        }
    }
    return QStringLiteral("unknown");
}

TestLabels parseLabels(const QString& labelStr)
{
    TestLabels labels;
    const QStringList parts = labelStr.split(',', Qt::SkipEmptyParts);

    for (const QString& part : parts) {
        TestLabel label = labelFromString(part);
        if (label != TestLabel::None) {
            labels |= label;
        }
    }

    return labels;
}

QString labelsToString(TestLabels labels)
{
    if (labels == TestLabels()) {
        return QStringLiteral("[]");
    }

    QStringList names;
    for (const auto& mapping : kLabelMappings) {
        if (labels.testFlag(mapping.label)) {
            names.append(QString::fromLatin1(mapping.name));
        }
    }

    return QStringLiteral("[") + names.join(QStringLiteral(", ")) + QStringLiteral("]");
}

QStringList availableLabelNames()
{
    QStringList names;
    names.reserve(std::size(kLabelMappings));
    for (const auto& mapping : kLabelMappings) {
        names.append(QString::fromLatin1(mapping.name));
    }
    return names;
}

// ============================================================================
// UnitTest Implementation
// ============================================================================

UnitTest::UnitTest(QObject* parent)
    : QObject(parent)
    , _expectedLogMessages(std::make_unique<ExpectedLogMessages>())
{
}

UnitTest::~UnitTest()
{
    // Only assert if actual test methods were run (init was called)
    // This handles the case where a base class is accidentally registered
    // or a test class has no test methods
    if (_unitTestRun && _initCalled) {
        Q_ASSERT(_cleanupCalled);
    }
}

void UnitTest::_addTest(UnitTest* test)
{
    QList<UnitTest*>& tests = _testList();
    Q_ASSERT(!tests.contains(test));
    tests.append(test);
}

QList<UnitTest*>& UnitTest::_testList()
{
    static QList<UnitTest*> tests;
    return tests;
}

QString& UnitTest::_outputFile()
{
    static QString outputFile;
    return outputFile;
}

void UnitTest::setOutputFile(const QString& outputFile)
{
    _outputFile() = outputFile;
}

QStringList UnitTest::registeredTests()
{
    QStringList names;
    for (const UnitTest* test : _testList()) {
        names.append(test->objectName());
    }
    return names;
}

QStringList UnitTest::registeredTests(TestLabels labelFilter)
{
    QStringList names;
    for (const UnitTest* test : _testList()) {
        // If no filter specified, include all tests
        // If filter specified, test must have at least one matching label
        if (labelFilter == TestLabels() || test->hasAnyLabel(labelFilter)) {
            names.append(test->objectName());
        }
    }
    return names;
}

int UnitTest::testCount()
{
    return _testList().size();
}

QStringList UnitTest::registeredLightweightTests(TestLabels labelFilter)
{
    QStringList names;
    for (const UnitTest* test : _testList()) {
        if (!test->lightweight() || test->standalone()) {
            continue;
        }
        if (labelFilter == TestLabels() || test->hasAnyLabel(labelFilter)) {
            names.append(test->objectName());
        }
    }
    return names;
}

bool UnitTest::isLightweightTest(QStringView testName)
{
    for (const UnitTest* test : _testList()) {
        if (testName == test->objectName()) {
            return test->lightweight();
        }
    }
    return false;
}

void UnitTest::setVerbose(bool verbose)
{
    TestDebug::setVerbose(verbose);
}

bool UnitTest::isVerbose()
{
    return TestDebug::isVerbose();
}

bool UnitTest::waitForSignal(QSignalSpy& spy, std::chrono::milliseconds timeout, QStringView signalName)
{
    QElapsedTimer waitTimer;
    waitTimer.start();

    if (spy.wait(timeout)) {
        return true;
    }

    const QString displayName = signalName.isEmpty() ? QStringLiteral("<unnamed>") : signalName.toString();
    qCWarning(UnitTestLog) << "Timeout waiting for signal" << displayName << "in" << currentTestName() << "after"
                           << waitTimer.elapsed() << "ms (timeout:" << timeout.count() << "ms, count:" << spy.count()
                           << ")";

    const QString context = TestContext::current();
    if (!context.isEmpty()) {
        qCWarning(UnitTestLog) << "Context:" << context;
    }

    logRecentDebugMessages("Recent test debug messages:");

    return false;
}

bool UnitTest::waitForNoSignal(QSignalSpy& spy, std::chrono::milliseconds timeout, QStringView signalName)
{
    const int initialCount = spy.count();
    QElapsedTimer waitTimer;
    waitTimer.start();

    const bool signalReceived = QTest::qWaitFor([&spy, initialCount]() { return spy.count() > initialCount; }, timeout);
    if (!signalReceived) {
        return true;
    }

    const QString displayName = signalName.isEmpty() ? QStringLiteral("<unnamed>") : signalName.toString();
    qCWarning(UnitTestLog) << "Unexpected signal" << displayName << "in" << currentTestName() << "after"
                           << waitTimer.elapsed() << "ms (timeout:" << timeout.count() << "ms, initial:" << initialCount
                           << ", current:" << spy.count() << ")";

    const QString context = TestContext::current();
    if (!context.isEmpty()) {
        qCWarning(UnitTestLog) << "Context:" << context;
    }

    logRecentDebugMessages("Recent test debug messages:");
    return false;
}

bool UnitTest::waitForSignalCount(QSignalSpy& spy, int expectedCount, std::chrono::milliseconds timeout, QStringView signalName)
{
    if (expectedCount <= 0 || spy.count() >= expectedCount) {
        return true;
    }

    QElapsedTimer waitTimer;
    waitTimer.start();

    if (QTest::qWaitFor([&spy, expectedCount]() { return spy.count() >= expectedCount; }, timeout)) {
        return true;
    }

    const QString displayName = signalName.isEmpty() ? QStringLiteral("<unnamed>") : signalName.toString();
    qCWarning(UnitTestLog) << "Timeout waiting for signal count" << displayName << "in" << currentTestName()
                           << "after" << waitTimer.elapsed() << "ms (timeout:" << timeout.count() << "ms, expected:"
                           << expectedCount << ", actual:" << spy.count() << ")";

    const QString context = TestContext::current();
    if (!context.isEmpty()) {
        qCWarning(UnitTestLog) << "Context:" << context;
    }

    logRecentDebugMessages("Recent test debug messages:");

    return false;
}

bool UnitTest::waitForCondition(const std::function<bool()>& condition, std::chrono::milliseconds timeout, QStringView conditionName)
{
    QElapsedTimer waitTimer;
    waitTimer.start();

    if (QTest::qWaitFor(condition, timeout)) {
        return true;
    }

    const QString displayName = conditionName.isEmpty() ? QStringLiteral("<unnamed>") : conditionName.toString();
    qCWarning(UnitTestLog) << "Timeout waiting for condition" << displayName << "in" << currentTestName() << "after"
                           << waitTimer.elapsed() << "ms (timeout:" << timeout.count() << "ms)";

    const QString context = TestContext::current();
    if (!context.isEmpty()) {
        qCWarning(UnitTestLog) << "Context:" << context;
    }

    logRecentDebugMessages("Recent test debug messages:");

    return false;
}

bool UnitTest::waitForDeleted(const QPointer<QObject>& objectPtr, std::chrono::milliseconds timeout, QStringView objectName)
{
    if (objectPtr.isNull()) {
        return true;
    }

    if (timeout <= std::chrono::milliseconds::zero()) {
        timeout = std::chrono::milliseconds(TestTimeout::mediumMs());
    }

    QElapsedTimer waitTimer;
    waitTimer.start();

    const bool deleted = QTest::qWaitFor(
        [&objectPtr]() {
            QCoreApplication::processEvents(QEventLoop::AllEvents);
            QCoreApplication::sendPostedEvents(nullptr, QEvent::DeferredDelete);
            return objectPtr.isNull();
        },
        timeout);
    if (deleted) {
        return true;
    }

    const QString displayName = objectName.isEmpty() ? QStringLiteral("<unnamed>") : objectName.toString();
    qCWarning(UnitTestLog) << "Timeout waiting for QObject deletion" << displayName << "in" << currentTestName()
                           << "after" << waitTimer.elapsed() << "ms (timeout:" << timeout.count()
                           << "ms, ptr:" << objectPtr.data() << ")";

    const QString context = TestContext::current();
    if (!context.isEmpty()) {
        qCWarning(UnitTestLog) << "Context:" << context;
    }

    logRecentDebugMessages("Recent test debug messages:");

    return false;
}

void UnitTest::settleEventLoopForCleanup(int iterations, int waitMs)
{
    if (iterations <= 0) {
        iterations = TestTimeout::isCI() ? 6 : 3;
    }
    if (waitMs < 0) {
        waitMs = TestTimeout::isCI() ? 10 : 5;
    }

    for (int i = 0; i < iterations; ++i) {
        QCoreApplication::processEvents(QEventLoop::AllEvents);
        QCoreApplication::sendPostedEvents(nullptr, QEvent::DeferredDelete);
        if (i < iterations - 1 && waitMs > 0) {
            QTest::qWait(waitMs);
        }
    }
}

VehicleComponent *UnitTest::findVehicleComponent(Vehicle *vehicle, const QString &name)
{
    if (!vehicle || !vehicle->autopilotPlugin()) {
        return nullptr;
    }

    const QVariantList components = vehicle->autopilotPlugin()->vehicleComponents();
    for (const QVariant &compVariant : components) {
        auto *comp = compVariant.value<VehicleComponent *>();
        if (comp && (comp->name() == name)) {
            return comp;
        }
    }
    return nullptr;
}

int UnitTest::run(QStringView singleTest, const QString& outputFile, TestLabels labelFilter)
{
    int ret = 0;
    int passed = 0;
    int failed = 0;
    int skipped = 0;
    QElapsedTimer totalTimer;
    totalTimer.start();

    // Set output file if provided
    if (!outputFile.isEmpty()) {
        setOutputFile(outputFile);
    }

    // Print header
    qCInfo(UnitTestLog) << "═══════════════════════════════════════════════════════════════";
    qCInfo(UnitTestLog) << " QGroundControl Unit Tests";
    qCInfo(UnitTestLog) << "═══════════════════════════════════════════════════════════════";

    if (isVerbose()) {
        qCInfo(UnitTestLog) << "Verbose mode enabled (QGC_TEST_VERBOSE=1)";
    }

    QStringList failedTests;

    for (UnitTest* test : _testList()) {
        // Check if this test should run
        bool shouldRun = false;

        if (!singleTest.isEmpty()) {
            // Specific test requested - check name match
            shouldRun = (singleTest == test->objectName());
        } else {
            // No specific test - check labels and standalone
            if (test->standalone()) {
                skipped++;
                continue;  // Skip standalone tests unless explicitly requested
            }

            // If label filter specified, check if test has matching labels
            if (labelFilter != TestLabels()) {
                shouldRun = test->hasAnyLabel(labelFilter);
            } else {
                shouldRun = true;  // No filter, run all non-standalone tests
            }
        }

        if (!shouldRun) {
            skipped++;
            continue;
        }

        // Clear debug messages before each test class
        TestDebug::clearMessages();

        bool maxWarningsOk = false;
        const int configuredMaxWarnings = qEnvironmentVariableIntValue("QGC_TEST_MAXWARNINGS", &maxWarningsOk);
        const int maxWarnings = (maxWarningsOk && configuredMaxWarnings >= 0) ? configuredMaxWarnings : 100;

        QStringList args;
        args << "*" << "-maxwarnings" << QString::number(maxWarnings);

        // Add JUnit XML output if configured
        if (!_outputFile().isEmpty()) {
            // Create unique output file per test class to avoid overwriting
            QString testOutputFile = _outputFile();
            if (testOutputFile.endsWith(QStringLiteral(".xml"))) {
                testOutputFile.insert(testOutputFile.length() - 4, QStringLiteral("-") + test->objectName());
            } else {
                testOutputFile += QStringLiteral("-") + test->objectName() + QStringLiteral(".xml");
            }
            args << "-o" << (testOutputFile + QStringLiteral(",junitxml"));
        }

        QElapsedTimer testTimer;
        testTimer.start();

        const int testResult = QTest::qExec(test, args);

        const qint64 elapsed = testTimer.elapsed();

        if (testResult != 0) {
            failed++;
            failedTests.append(test->objectName());

            // Print failure details
            qCWarning(UnitTestLog) << "╭─────────────────────────────────────────────────────────────╮";
            qCWarning(UnitTestLog) << "│ FAILED:" << test->objectName();
            qCWarning(UnitTestLog) << "╰─────────────────────────────────────────────────────────────╯";

            // Print test context if available
            const QString context = TestContext::current();
            if (!context.isEmpty()) {
                qCWarning(UnitTestLog) << "Context:" << context;
            }

            // Print recent debug messages
            const QStringList& debugMsgs = TestDebug::recentMessages();
            if (!debugMsgs.isEmpty()) {
                qCWarning(UnitTestLog) << "Recent debug output:";
                for (const QString& msg : debugMsgs) {
                    qCWarning(UnitTestLog) << "  " << msg;
                }
            }
        } else {
            passed++;
            if (isVerbose()) {
                qCInfo(UnitTestLog) << "✓" << test->objectName() << QString("(%1ms)").arg(elapsed);
            }
        }

        ret += testResult;
    }

    // Print summary
    const qint64 totalElapsed = totalTimer.elapsed();
    qCInfo(UnitTestLog) << "═══════════════════════════════════════════════════════════════";
    qCInfo(UnitTestLog) << "Test Summary";
    qCInfo(UnitTestLog) << "───────────────────────────────────────────────────────────────";
    qCInfo(UnitTestLog) << "  Passed: " << passed;
    if (failed > 0) {
        qCWarning(UnitTestLog) << "  Failed: " << failed;
    }
    if (skipped > 0) {
        qCInfo(UnitTestLog) << "  Skipped:" << skipped;
    }
    qCInfo(UnitTestLog) << "  Total:  " << (passed + failed);
    qCInfo(UnitTestLog) << "  Time:   " << QString("%1s").arg(totalElapsed / 1000.0, 0, 'f', 2);

    if (!failedTests.isEmpty()) {
        qCWarning(UnitTestLog) << "Failed tests:";
        for (const QString& name : failedTests) {
            qCWarning(UnitTestLog) << "  •" << name;
        }
    }

    qCInfo(UnitTestLog) << "═══════════════════════════════════════════════════════════════";

    return ret;
}

// ============================================================================
// Test‑time capture handler
// ============================================================================
// QTest::qExec() replaces the application message handler with its own.
// Our LogManager::msgHandler is therefore NOT called during test execution.
// We work around this by installing a thin wrapper ON TOP of QTest's handler
// inside initTestCase() and restoring it in cleanupTestCase().
// The wrapper captures messages for the test log‑capture API and then chains
// to QTest's handler so QWARN / QCRITICAL output keeps working.

static std::atomic<QtMessageHandler> s_qtestHandler{nullptr};

static void testCaptureHandler(QtMsgType type, const QMessageLogContext &context, const QString &msg)
{
    // Capture for unit‑test introspection
    LogManager::captureIfEnabled(type, context, msg);

    // Chain to QTest's handler for normal test output
    const QtMessageHandler handler = s_qtestHandler.load(std::memory_order_acquire);
    if (handler) {
        handler(type, context, msg);
    }
}

void UnitTest::initTestCase()
{
    // Reset test tracking state at start of each test class
    _resetTestState();

    // Install the capture wrapper on top of QTest's handler
    s_qtestHandler.store(qInstallMessageHandler(testCaptureHandler), std::memory_order_release);
}

void UnitTest::cleanupTestCase()
{
    // Restore QTest's handler so qExec teardown stays consistent
    const QtMessageHandler prev = s_qtestHandler.exchange(nullptr, std::memory_order_acq_rel);
    if (prev) {
        (void)qInstallMessageHandler(prev);
    }
}

void UnitTest::expectLogMessage(const char *category, QtMsgType type, const QRegularExpression &pattern)
{
    Q_ASSERT_X(category && *category != '\0', "expectLogMessage", "category must not be empty — use the exact Qt logging category string (e.g. \"Utilities.QGCFileHelper\")");
    _expectedLogMessages->pending.append({
        .entry = {LogEntry::fromQtMsgType(type), pattern, QString::fromLatin1(category)},
        .startIndex = static_cast<int>(LogManager::capturedMessages().size()),
    });
}

void UnitTest::verifyExpectedLogMessage()
{
    if (_expectedLogMessages->pending.isEmpty()) {
        QFAIL("verifyExpectedLogMessage called with no pending expectLogMessage.");
    }

    auto matches = [](const LogEntry &m, const ExpectedLogMessages::Entry &e) {
        if (e.level != m.level) {
            return false;
        }
        if (!e.pattern.match(m.message).hasMatch()) {
            return false;
        }
        if (e.category != m.category) {
            return false;
        }
        return true;
    };

    const ExpectedLogMessages::PendingExpectation expected = _expectedLogMessages->pending.front();

    const auto allMsgs = LogManager::capturedMessages();
    for (int i = expected.startIndex; i < allMsgs.size(); ++i) {
        if (_expectedLogMessages->consumedMessageIndices.contains(i)) {
            continue;
        }
        if (!matches(allMsgs[i], expected.entry)) {
            continue;
        }

        _expectedLogMessages->consumedMessageIndices.insert(i);
        _expectedLogMessages->pending.removeFirst();
        return;
    }

    const QString detail = QStringLiteral("Expected log message was not captured after expectLogMessage. pattern='%1' category='%2'")
                               .arg(expected.entry.pattern.pattern(),
                                    expected.entry.category);
    _expectedLogMessages->pending.removeFirst();
    QFAIL(qPrintable(detail));
}

void UnitTest::expectAppMessage(const QRegularExpression &messagePattern)
{
    expectLogMessage("API.QGCApplication.AppMessage", QtDebugMsg, messagePattern);
}

void UnitTest::ignoreLogMessage(const char *category, QtMsgType type, const QRegularExpression &pattern)
{
    Q_ASSERT_X(category && *category != '\0', "ignoreLogMessage", "category must not be empty — use the exact Qt logging category string (e.g. \"Utilities.QGCFileHelper\")");
    _expectedLogMessages->ignored.append({LogEntry::fromQtMsgType(type), pattern, QString::fromLatin1(category)});
}

bool UnitTest::apmFirmwareSupported()
{
    return FirmwarePluginManager::instance()->firmwareClassSupported(QGCMAVLink::FirmwareClassArduPilot);
}

void UnitTest::init()
{
    _initCalled = true;
    _failureContextDumped = false;
    _expectedLogMessages->ignored.clear();
    _expectedLogMessages->pending.clear();
    _expectedLogMessages->consumedMessageIndices.clear();

    // showRebootAppMessage() debounces repeats (2 min) across tests — reset so each
    // test deterministically sees its own reboot message. Lightweight harness runs a
    // bare QCoreApplication, hence the cast check.
    if (auto *app = qobject_cast<QGCApplication *>(QCoreApplication::instance())) {
        app->resetRebootMessageDebounce();
    }

    // MockLink emulates an Open Drone ID device (sends OPEN_DRONE_ID_ARM_STATUS at
    // 1Hz), which makes RemoteIDManager start its periodic send timer. That timer
    // warns about the missing GCS GPS fix — but headless unit tests never have a
    // GCS GPS source, so this is expected noise. Whether the timer ticks inside a
    // given test's strict-mode capture window is timing-dependent, so without this
    // ignore the warning lands in a random test each full run, causing flaky
    // failures across many vehicle/UI tests. Ignore it globally.
    ignoreLogMessage("Vehicle.RemoteIDManager", QtWarningMsg,
                     QRegularExpression(QStringLiteral("^GCS GPS error:")));

    // offscreen QPA exposes no GLX/EGL display, so Qt 6.11's QRhiGles2 probe can't
    // create a context and warns; UI tests use the software backend, so it's benign.
    ignoreLogMessage("default", QtWarningMsg,
                     QRegularExpression(QStringLiteral("^QRhiGles2: Failed to create")));

    // QQuickPinchArea declares its own `enabled` property (gesture enable, distinct
    // from QQuickItem::enabled); Qt 6.11's property-cache shadow check warns once per
    // QML engine. A framework quirk, not QGC's — every UI test scene hits it.
    ignoreLogMessage("qt.qml.propertyCache.append", QtWarningMsg,
                     QRegularExpression(QStringLiteral("QQuickPinchArea overrides a member")));

    // QtGraphs warns when a LineSeries is given the GraphsView's own axes (redundant
    // association); cosmetic, the chart still renders. Surfaces in the Analyze charts.
    ignoreLogMessage("qt.graphs2d.axis.properties", QtWarningMsg,
                     QRegularExpression(QStringLiteral("axis already associated with")));

    // Headless software-GL (xvfb) gives GStreamer no usable X11/EGL GL context, so the
    // GL bridge disables itself and falls back to software decode — by design in tests.
    ignoreLogMessage("Video.GStreamer.HwBuffers.GstGlBridge", QtWarningMsg,
                     QRegularExpression(QStringLiteral("GL bridge disabled")));

    // Start capturing log messages for this test (cleared from previous test)
    LogManager::clearCapturedMessages();
    LogManager::setCaptureEnabled(true);

    // Per-test settings isolation. QGCApplication clears settings once at process startup
    // when running unit tests, but every test function of a class shares that one process,
    // so persisted QSettings values written by one test function (or left over from a prior
    // crashed run) otherwise bleed into the next. Clear the persistent store at the start of
    // every test function so each starts from an empty scope.
    {
        QSettings settings;
        settings.clear();
        settings.sync();
    }

    // Force offline vehicle back to defaults. Lightweight (bare QCoreApplication) tests run
    // without the SettingsManager toolbox, so guard against a missing AppSettings rather than
    // dereferencing null.
    // Note: There is deliberately no generic "reset all settings facts to defaults" sweep here.
    // Some facts (e.g. AppSettings::savePath) are boot-initialized programmatically to values
    // that differ from their JSON defaults; resetting them to defaults mid-run breaks the app
    // (savePath in particular falls back to relative paths under the ctest cwd — the build
    // directory). Tests that mutate settings facts must save and restore them explicitly.
    if (AppSettings* const appSettings = SettingsManager::instance()->appSettings()) {
        appSettings->offlineEditingFirmwareClass()->setRawValue(
            appSettings->offlineEditingFirmwareClass()->rawDefaultValue());
        appSettings->offlineEditingVehicleClass()->setRawValue(
            appSettings->offlineEditingVehicleClass()->rawDefaultValue());
    }
}

void UnitTest::cleanup()
{
    _cleanupCalled = true;
    dumpFailureContextIfTestFailed(QStringLiteral("cleanup"));

    // Keep log capture enabled through the settle/verification phase so warnings
    // emitted while draining queued events are still subject to strict checking.
    // The scope guard guarantees capture is disabled on every exit path, including
    // the early returns taken by the QFAIL macros below.
    const auto captureGuard = qScopeGuard([] { LogManager::setCaptureEnabled(false); });

    // Drain queued events and flush DeferredDelete across several passes to
    // prevent cross-test contamination; a single qWait(0) pass is insufficient.
    settleEventLoopForCleanup();

    // Fail the test if any unexpected captured log messages were emitted (strict mode).
    // Skip if the test already failed to avoid noisy double-failure reports.
    if (!QTest::currentTestFailed()) {
        if (!_expectedLogMessages->pending.isEmpty()) {
            const auto expected = _expectedLogMessages->pending.front().entry;
            _expectedLogMessages->pending.clear();
            const QString detail = QStringLiteral("expectLogMessage was called without a matching verifyExpectedLogMessage. pattern='%1' category='%2'")
                                       .arg(expected.pattern.pattern(), expected.category);
            QFAIL(qPrintable(detail));
        }

        auto isIgnored = [this](const LogEntry &m) {
            for (const auto &e : _expectedLogMessages->ignored) {
                if (e.level != m.level) continue;
                if (!e.pattern.match(m.message).hasMatch()) continue;
                if (e.category != m.category) continue;
                return true;
            }
            return false;
        };

        const auto allMsgs = LogManager::capturedMessages();
        QString strictDetails;
        for (int i = 0; i < allMsgs.size(); ++i) {
            if (_expectedLogMessages->consumedMessageIndices.contains(i)) {
                continue;
            }
            const LogEntry &m = allMsgs[i];
            if (isIgnored(m)) {
                continue;
            }
            const char *lvl = (m.level == LogEntry::Debug)    ? "debug"
                            : (m.level == LogEntry::Warning)  ? "warning"
                            : (m.level == LogEntry::Info)     ? "info"
                            : (m.level == LogEntry::Critical) ? "critical"
                                                              : "other";
            strictDetails += QStringLiteral("  [%1][%2] %3\n")
                                 .arg(QLatin1String(lvl), m.category, m.message);
        }

        if (!strictDetails.isEmpty()) {
            QFAIL(qPrintable(QStringLiteral("Unexpected log messages (strict mode):\n%1").arg(strictDetails)));
        }
    }
}

void UnitTest::dumpFailureContextIfTestFailed(QStringView reason)
{
    if (_failureContextDumped || !QTest::currentTestFailed()) {
        return;
    }

    _failureContextDumped = true;

    const QString testFunction = currentTestName();
    if (reason.isEmpty()) {
        qCWarning(UnitTestLog) << "Failure context dump for" << objectName() << "::" << testFunction;
    } else {
        qCWarning(UnitTestLog) << "Failure context dump for" << objectName() << "::" << testFunction << "("
                               << reason.toString() << ")";
    }

    const QString context = TestContext::current();
    if (!context.isEmpty()) {
        qCWarning(UnitTestLog) << "Context:" << context;
    }

    const QString fixtureSummary = failureContextSummary();
    if (!fixtureSummary.isEmpty()) {
        qCWarning(UnitTestLog) << "Fixture state:";
        const QStringList lines = fixtureSummary.split('\n', Qt::SkipEmptyParts);
        for (const QString& line : lines) {
            qCWarning(UnitTestLog).noquote() << "  " << line;
        }
    }

    logRecentDebugMessages("Recent test debug messages:");
}

QString UnitTest::failureContextSummary() const
{
    QStringList lines;

    if (!qgcApp()) {
        lines.append(QStringLiteral("QGC application instance is not available"));
        return lines.join('\n');
    }

    MultiVehicleManager* vehicleManager = MultiVehicleManager::instance();
    QmlObjectListModel* vehicles = vehicleManager ? vehicleManager->vehicles() : nullptr;
    const int vehicleCount = vehicles ? vehicles->count() : 0;
    Vehicle* activeVehicle = vehicleManager ? vehicleManager->activeVehicle() : nullptr;

    lines.append(QStringLiteral("MultiVehicleManager: vehicles=%1 activeVehicle=%2")
                     .arg(vehicleCount)
                     .arg(activeVehicle ? QStringLiteral("present") : QStringLiteral("null")));
    if (activeVehicle) {
        lines.append(QStringLiteral("Active vehicle: id=%1 initialConnectComplete=%2")
                         .arg(activeVehicle->id())
                         .arg(activeVehicle->isInitialConnectComplete()));
    }

    LinkManager* linkManager = LinkManager::instance();
    const int linkCount = linkManager ? linkManager->links().count() : 0;
    lines.append(QStringLiteral("LinkManager: links=%1").arg(linkCount));

    return lines.join('\n');
}

void UnitTest::_resetTestState()
{
    _unitTestRun = true;
    _initCalled = false;
    _cleanupCalled = false;
}

bool UnitTest::fileCompare(const QString& file1, const QString& file2)
{
    QFile f1(file1);
    QFile f2(file2);

    if (!f1.open(QIODevice::ReadOnly)) {
        qCWarning(UnitTestLog) << "fileCompare: cannot open file1:" << f1.errorString();
        return false;
    }
    if (!f2.open(QIODevice::ReadOnly)) {
        qCWarning(UnitTestLog) << "fileCompare: cannot open file2:" << f2.errorString();
        return false;
    }

    const qint64 size1 = f1.size();
    const qint64 size2 = f2.size();
    if (size1 != size2) {
        qCWarning(UnitTestLog) << "fileCompare: sizes differ -" << size1 << "vs" << size2;
        return false;
    }

    if (size1 == 0) {
        return true;
    }

    // Memory-map both files for zero-copy comparison
    const uchar* m1 = f1.map(0, size1);
    const uchar* m2 = f2.map(0, size2);

    if (m1 && m2) {
        if (std::memcmp(m1, m2, static_cast<size_t>(size1)) == 0) {
            return true;
        }
        // Find exact mismatch position for diagnostics
        for (qint64 i = 0; i < size1; ++i) {
            if (m1[i] != m2[i]) {
                qCWarning(UnitTestLog) << "fileCompare: mismatch at offset" << i << "- got"
                                       << static_cast<int>(m1[i]) << "expected" << static_cast<int>(m2[i]);
                return false;
            }
        }
        return false;
    }

    // Fallback to buffered read if mapping fails (e.g. special filesystems)
    qint64 offset = 0;
    while (!f1.atEnd()) {
        const QByteArray buf1 = f1.read(kFileCompareBufferSize);
        const QByteArray buf2 = f2.read(kFileCompareBufferSize);
        if (buf1 != buf2) {
            for (int i = 0; i < buf1.size() && i < buf2.size(); ++i) {
                if (buf1[i] != buf2[i]) {
                    qCWarning(UnitTestLog) << "fileCompare: mismatch at offset" << (offset + i) << "- got"
                                           << static_cast<int>(buf1[i]) << "expected" << static_cast<int>(buf2[i]);
                    return false;
                }
            }
            return false;
        }
        offset += buf1.size();
    }

    return true;
}

bool UnitTest::fileContentsEqual(const QString& filePath, const QString& expectedContent)
{
    return fileContentsEqual(filePath, expectedContent.toUtf8());
}

bool UnitTest::fileContentsEqual(const QString& filePath, const QByteArray& expectedContent)
{
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly)) {
        qCWarning(UnitTestLog) << "fileContentsEqual: cannot open file:" << file.errorString();
        return false;
    }

    const QByteArray actualContent = file.readAll();
    if (actualContent != expectedContent) {
        qCWarning(UnitTestLog) << "fileContentsEqual: content mismatch" << "- actual size:" << actualContent.size()
                               << "expected size:" << expectedContent.size();
        return false;
    }

    return true;
}

QString UnitTest::testResourcePath(const QString& relativePath)
{
    // Try to find test resources relative to the source directory
    // basePath is computed once and cached
    static const QString basePath = []() {
        const QString appDir = QCoreApplication::applicationDirPath();
        const QStringList candidates = {
            appDir + QStringLiteral("/../../test/resources"),
            appDir + QStringLiteral("/../test/resources"),
            appDir + QStringLiteral("/test/resources"),
            QStringLiteral(QT_TESTCASE_SOURCEDIR "/resources"),
        };

        for (const QString& candidate : candidates) {
            if (QDir(candidate).exists()) {
                return QDir(candidate).absolutePath();
            }
        }

        qCWarning(UnitTestLog) << "testResourcePath: could not find test resources directory";
        return QStandardPaths::writableLocation(QStandardPaths::TempLocation);
    }();

    if (relativePath.isEmpty()) {
        return basePath;
    }

    return basePath + QStringLiteral("/") + relativePath;
}
