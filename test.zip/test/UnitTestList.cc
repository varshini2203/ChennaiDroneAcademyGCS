#include "UnitTestList.h"

#include <QtCore/QCoreApplication>
#include <QtCore/QElapsedTimer>
#include <QtCore/QSet>

#include "QGCLoggingCategory.h"
#include "UnitTestTileGenerator.h"

QGC_LOGGING_CATEGORY(UnitTestListLog, "Test.UnitTestList")

// ============================================================================
// Test Execution Functions
// ============================================================================

namespace QGCUnitTest {

int runTests(const QStringList& unitTests, int iterations, const QString& outputFile, TestLabels labelFilter)
{
    // Serve synthetic tiles on tile cache misses so no test ever hits the network
    UnitTestTileGenerator::install();

    // Determine which tests to run
    QStringList testsToRun;
    if (unitTests.isEmpty()) {
        // No specific tests - run all matching the label filter
        testsToRun = registeredTestNames(labelFilter);
    } else {
        // Validate requested test names
        const QStringList invalid = validateTestNames(unitTests);
        if (!invalid.isEmpty()) {
            qCWarning(UnitTestListLog) << "Unknown test(s):" << invalid.join(", ");
            qCWarning(UnitTestListLog) << "Available tests:" << UnitTest::registeredTests().join(", ");
            return -static_cast<int>(invalid.size());
        }
        testsToRun = unitTests;
    }

    if (testsToRun.isEmpty()) {
        qCWarning(UnitTestListLog) << "No tests to run";
        return 0;
    }

    // Started only after the early returns above: the worker thread must be shut down
    // before returning (see shutdownMapEngine below), so don't start it until the run
    // is definitely happening.
    UnitTestTileGenerator::initMapEngine();

    iterations = qMax(1, iterations);
    int result = 0;

    for (int i = 0; i < iterations; ++i) {
        int failures = 0;

        for (const QString& test : testsToRun) {
            failures += UnitTest::run(test, outputFile, labelFilter);
        }

        if (failures == 0) {
            if (iterations > 1) {
                qCDebug(UnitTestListLog).noquote()
                    << QString("ALL TESTS PASSED (iteration %1/%2)").arg(i + 1).arg(iterations);
            } else {
                qCDebug(UnitTestListLog) << "ALL TESTS PASSED";
            }
        } else {
            qCWarning(UnitTestListLog) << failures << "TESTS FAILED!";
            result = -failures;
            break;
        }
    }

    // Stop the tile cache worker while the app still exists: its database teardown
    // cannot run after QApplication destruction.
    UnitTestTileGenerator::shutdownMapEngine();

    return result;
}

int runLightweightTests(const QStringList& unitTests, int iterations, const QString& outputFile,
                        TestLabels labelFilter)
{
    if (!QCoreApplication::instance()) {
        qCWarning(UnitTestListLog) << "runLightweightTests called with no QCoreApplication instance";
        return -1;
    }

    // Serve synthetic tiles on tile cache misses so no test ever hits the network
    UnitTestTileGenerator::install();

    QStringList testsToRun;
    if (unitTests.isEmpty()) {
        testsToRun = UnitTest::registeredLightweightTests(labelFilter);
    } else {
        QStringList nonLightweight;
        for (const QString& name : unitTests) {
            if (UnitTest::isLightweightTest(name)) {
                testsToRun.append(name);
            } else {
                nonLightweight.append(name);
            }
        }
        if (!nonLightweight.isEmpty()) {
            qCWarning(UnitTestListLog)
                << "Requested test(s) are not lightweight (must run on the full-app path):"
                << nonLightweight.join(QStringLiteral(", "));
            return -static_cast<int>(nonLightweight.size());
        }
    }

    if (testsToRun.isEmpty()) {
        qCInfo(UnitTestListLog) << "No lightweight tests to run";
        return 0;
    }

    iterations = qMax(1, iterations);
    int result = 0;
    for (int i = 0; i < iterations; ++i) {
        int failures = 0;
        for (const QString& test : testsToRun) {
            failures += UnitTest::run(test, outputFile, labelFilter);
        }
        if (failures != 0) {
            qCWarning(UnitTestListLog) << failures << "LIGHTWEIGHT TESTS FAILED!";
            result = -failures;
            break;
        }
    }
    return result;
}

QStringList registeredTestNames()
{
    return UnitTest::registeredTests();
}

QStringList registeredTestNames(TestLabels labelFilter)
{
    return UnitTest::registeredTests(labelFilter);
}

int registeredTestCount()
{
    return UnitTest::testCount();
}

bool isTestRegistered(const QString& testName)
{
    return UnitTest::registeredTests().contains(testName);
}

QStringList validateTestNames(const QStringList& testNames)
{
    const QStringList registered = UnitTest::registeredTests();

    // Use QSet for O(1) lookup instead of O(n) QStringList::contains()
    const QSet<QString> registeredSet(registered.cbegin(), registered.cend());

    QStringList invalid;
    invalid.reserve(testNames.size());

    for (const QString& name : testNames) {
        if (!registeredSet.contains(name)) {
            invalid.append(name);
        }
    }

    return invalid;
}

int handleTestOptions(const QGCCommandLineParser::CommandLineParseResult& args)
{
    // Parse label filter if provided
    TestLabels labelFilter;
    if (args.labelFilter.has_value() && !args.labelFilter->isEmpty()) {
        const QStringList requestedLabels = args.labelFilter->split(',', Qt::SkipEmptyParts);
        QStringList invalidLabels;
        invalidLabels.reserve(requestedLabels.size());
        for (const QString& labelName : requestedLabels) {
            if (labelFromString(labelName) == TestLabel::None) {
                invalidLabels.append(labelName.trimmed());
            }
        }
        if (!invalidLabels.isEmpty()) {
            qCWarning(UnitTestListLog) << "Invalid label(s):" << invalidLabels.join(", ");
            qCWarning(UnitTestListLog) << "Available labels:" << availableLabelNames().join(", ");
            return -1;
        }

        labelFilter = parseLabels(args.labelFilter.value());
        if (labelFilter == TestLabels()) {
            qCWarning(UnitTestListLog) << "Invalid label filter:" << args.labelFilter.value();
            qCWarning(UnitTestListLog) << "Available labels:" << availableLabelNames().join(", ");
            return -1;
        }
    }

    // Handle --list-tests
    if (args.listTests) {
        const QStringList tests = registeredTestNames(labelFilter);
        const QString filterDesc =
            labelFilter != TestLabels() ? QString(" matching %1").arg(labelsToString(labelFilter)) : QString();

        qCInfo(UnitTestListLog).noquote() << QString("Available unit tests%1: %2").arg(filterDesc).arg(tests.count());

        for (const QString& test : tests) {
            qInfo().noquote() << "  " << test;
        }

        qCInfo(UnitTestListLog).noquote() << QString("\nAvailable labels: %1").arg(availableLabelNames().join(", "));

        return 0;
    }

    // Handle --unittest
    if (args.runningUnitTests) {
        // Count tests that will run
        const QStringList testsToRun = args.unitTests.isEmpty() ? registeredTestNames(labelFilter) : args.unitTests;
        const int testCount = testsToRun.count();

        const QString filterDesc =
            labelFilter != TestLabels() ? QString(" %1").arg(labelsToString(labelFilter)) : QString();

        qCInfo(UnitTestListLog).noquote() << QString("Running %1 unit test(s)%2...").arg(testCount).arg(filterDesc);

        QElapsedTimer timer;
        timer.start();

        const int stressIterations =
            args.stressUnitTests
                ? static_cast<int>(args.stressUnitTestsCount > 0 ? args.stressUnitTestsCount : kStressIterations)
                : 1;

        const int exitCode =
            runTests(args.unitTests, stressIterations, args.unitTestOutput.value_or(QString()), labelFilter);

        const qint64 elapsed = timer.elapsed();
        if (exitCode == 0) {
            qCInfo(UnitTestListLog).noquote() << QString("All %1 test(s) passed in %2 ms").arg(testCount).arg(elapsed);
        } else {
            qCWarning(UnitTestListLog).noquote()
                << QString("%1 test(s) failed (ran in %2 ms)").arg(-exitCode).arg(elapsed);
        }
        return exitCode;
    }

    return 0;
}

}  // namespace QGCUnitTest
